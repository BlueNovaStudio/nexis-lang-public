# 🎓 Guías de ejercicios de Nexis

Este documento contiene las **guías de ejercicios** del lenguaje Nexis. Cada guía tiene un objetivo, una lista de ejercicios con **solución paso a paso** y una sección de **práctica de errores** para aprender a identificar y corregir los códigos NX documentados en el [catálogo de errores](../docs/language/errors/errors.md).

> **Cómo usar estas guías:**
> 1. Intenta resolver cada ejercicio **sin mirar la solución**.
> 2. Compara con la solución, que aparece debajo de cada ejercicio.
> 3. La sección "Qué debería romper" lista programas incorrectos: ejecútalos, anota el código NX y corrígelos.
>
> Los archivos de prueba correspondientes están en las carpetas `01 variables/` … `08 modulos/` y el proyecto integrador en `09 integrador/`.

---

# Guía 00 — Variables, tipos y operadores

**Objetivo:** validar declaración de variables, tipado y todos los operadores (aritméticos, relacionales, lógicos, de asignación).

## Ejercicios

### Ejercicio 1: Declarar una variable de cada tipo básico

Declara una variable de cada tipo básico de Nexis (entero, real, texto, booleano) e imprímelas.

```nexis
int entero = 42
float real = 3.5f
double alto = 123.456
char letra = 'A'
string texto = "Hola Nexis"
bool buleano = true

Console.print(entero)
Console.print(real)
Console.print(alto)
Console.print(letra)
Console.print(texto)
Console.print(buleano)
```

**Observa:** `float` usa sufijo `f`; `auto` podría deducir cada tipo, pero declarar el tipo explícito hace el código más claro.

### Ejercicio 2: Operaciones básicas con dos números

Lee dos números por teclado y muestra su suma, resta, multiplicación, división entera y módulo.

```nexis
int a = Console.input(text="Número a: ")
int b = Console.input(text="Número b: ")

Console.print("Suma: " + (a + b))
Console.print("Resta: " + (a - b))
Console.print("Multiplicación: " + (a * b))
Console.print("División: " + (a / b))
Console.print("Módulo: " + (a % b))
```

**Recuerda:** la división entre enteros devuelve un entero. Para decimales usa `float`/`double`.

### Ejercicio 3: Área y perímetro de un círculo

Dado el radio de un círculo, calcula área y perímetro usando una constante `PI` declarada aparte.

```nexis
#inject math;

const double PI = 3.14159

double radio = Console.input(text="Ingresa el radio: ")

double area = PI * radio * radio
double perimetro = 2 * PI * radio

Console.print("El area del circulo es: ", area)
Console.print("El perimetro del circulo es: ", perimetro)
```

**Observa:** `Console.print` acepta varios argumentos separados por coma.

### Ejercicio 4: Intercambiar dos variables sin auxiliar

Intercambia el valor de dos variables sin usar una tercera variable auxiliar.

```nexis
int a = 3
int b = 2

a = a + b
b = a - b
a = a - b

Console.print(fs"a: {a} | b: {b}")   // a: 2 | b: 3
```

**Paso a paso:**
1. `a = a + b` → `a = 5`.
2. `b = a - b` → `b = 5 - 2 = 3`.
3. `a = a - b` → `a = 5 - 3 = 2`.

### Ejercicio 5: Precedencia de operadores

Pide 3 números `a, b, c` y calcula `a + b * c`, `(a + b) * c`, `a > b && b > c`, `!(a == b)`.

```nexis
int a = Console.input(text="Primer número: ")
int b = Console.input(text="Segundo número: ")
int c = Console.input(text="Tercer número: ")

Console.print("a + b * c = " + (a + b * c))       // multiplica primero
Console.print("(a + b) * c = " + ((a + b) * c))   // paréntesis primero
Console.print("a > b && b > c = " + ((a > b) && (b > c)))
Console.print("!(a == b) = " + (!(a == b)))
```

### Ejercicio 6: Conversión de temperatura

Convierte una temperatura de Celsius a Fahrenheit y viceversa en el mismo programa.

```nexis
float celsius = Console.input(text="Grados Celsius: ")
float fahrenheit = celsius * (9.0 / 5) + 32
Console.print("En Fahrenheit: ", fahrenheit)

float otra = Console.input(text="Grados Fahrenheit: ")
float celsius2 = (otra - 32) * (5.0 / 9)
Console.print("En Celsius: ", celsius2)
```

> **Detalle importante:** usa `9.0 / 5` (no `9 / 5`). Como `9 / 5` divide enteros, devuelve `1` y rompería el cálculo.

### Ejercicio 7: Variable sin inicializar (error esperado)

Declara una variable sin inicializar y trata de usarla antes de asignarle valor. Anota el error que esperas que lance Nexis.

```nexis
int x
Console.print(x)   // ERROR esperado: NX00 (variable no inicializada)
```

**Respuesta esperada:** NX00. La variable existe pero no tiene valor; usarla antes de inicializar produce el error NX00.

### Ejercicio 8: Reasignar una constante (error esperado)

Declara una constante y luego intenta reasignarla. Anota el error esperado.

```nexis
const int x = 3
x = 4   // ERROR esperado: NX03 (no se puede modificar una constante)
```

**Respuesta esperada:** NX03. Las constantes se inicializan una sola vez.

## Qué debería romper (práctica de errores)

Para cada fragmento, ejecútalo, anota el código NX que aparece y corrige el problema.

| # | Código incorrecto | Error esperado | Corrección |
|---|-------------------|----------------|------------|
| 1 | `int númer o = 5` | NX05 (identificador inválido) | `int numero = 5` |
| 2 | `int _a = 1` y luego `int 2b = 3` | NX05 (no puede empezar con número) | `int b2 = 3` |
| 3 | `int x = 5` y luego `int x = 10` en el mismo bloque | NX04 (declaración duplicada) | `x = 10` |
| 4 | `int r = "5" + 5` | NX10 (operandos incompatibles) | `int r = int("5") + 5` |
| 5 | `bool r = true + 1` | NX10 (operandos incompatibles) | `int r = 1 + 1` (o rediseñar) |
| 6 | `int v = 10 / 0` | NX01 (división por cero) | validar el divisor distinto de 0 |
| 7 | Comentario `#/* ... ` sin cerrar `*/#` | NX91 (comentario mal cerrado) | cerrar el bloque |
| 8 | `string s = "Hola\n` sin comilla final | NX91 (cadena mal cerrada) | cerrar la cadena con `"` |

---

# Guía 01 — Estructuras condicionales

**Objetivo:** `if`, `else if`, `else`, anidamiento y operadores lógicos.

## Ejercicios

### Ejercicio 1: Positivo, negativo o cero

Dado un número, indica si es positivo, negativo o cero.

```nexis
int n = Console.input(text="Ingresa un numero: ")

if (n > 0) {
    Console.print("EL numero es positivo")
} else if (n < 0) {
    Console.print("EL numero es negativo")
} else {
    Console.print("EL numero es 0")
}
```

### Ejercicio 2: Vocal o consonante

Dado un carácter, determina si es vocal.

```nexis
char caracter = Console.input(text="Ingrese un caracter: ")

switch (caracter) {
    case 'a': case 'A':
    case 'e': case 'E':
    case 'i': case 'I':
    case 'o': case 'O':
    case 'u': case 'U':
        Console.print("El caracter ingresado es vocal")
        break
    default:
        Console.print("El caracter ingresado no es vocal")
}
```

### Ejercicio 3: Aprobado o desaprobado

Dadas tres notas, calcula el promedio e indica "Aprobado" o "Desaprobado" (umbral 10.5).

```nexis
int n1 = Console.input(text="Nota 1: ")
int n2 = Console.input(text="Nota 2: ")
int n3 = Console.input(text="Nota 3: ")

float promedio = (n1 + n2 + n3) / 3.0

if (promedio >= 10.5):
    Console.print("Aprobado")
else:
    Console.print("Desaprobado")
```

### Ejercicio 4: Año bisiesto

Dado un año, determina si es bisiesto (condicionales anidadas + módulo + `&&`/`||`).

```nexis
int anio = Console.input(text="Año: ")

#/ Un año es bisiesto si es divisible entre 4, excepto los múltiplos
#/ de 100 que no sean múltiplos de 400.

if (anio % 400 == 0) {
    Console.print("Es bisiesto")
} else if (anio % 100 == 0) {
    Console.print("No es bisiesto")
} else if (anio % 4 == 0) {
    Console.print("Es bisiesto")
} else {
    Console.print("No es bisiesto")
}
```

### Ejercicio 5: Tipo de triángulo

Dados tres lados, determina si forman un triángulo y, si lo forman, si es equilátero, isósceles o escaleno.

```nexis
float a = Console.input(text="Lado 1: ")
float b = Console.input(text="Lado 2: ")
float c = Console.input(text="Lado 3: ")

if (a + b > c && a + c > b && b + c > a) {
    if (a == b && b == c) {
        Console.print("Equilátero")
    } else if (a == b || b == c || a == c) {
        Console.print("Isósceles")
    } else {
        Console.print("Escaleno")
    }
} else {
    Console.print("No forman un triángulo")
}
```

### Ejercicio 6: Función a trozos

Evalúa la función a trozos:
```
f(x) = x² + 1        si x <= 0
f(x) = x² + 3x + 2   si 0 < x < 3
f(x) = x + 1         si x >= 3
```

```nexis
float x = Console.input(text="Valor de x: ")
float resultado

if (x <= 0) {
    resultado = x * x + 1
} else if (x < 3) {
    resultado = x * x + 3 * x + 2
} else {
    resultado = x + 1
}

Console.print("f(" + x + ") = " + resultado)
```

### Ejercicio 7: Estación del año

Dado un número de mes (1-12), imprime la estación del año usando `switch` y luego el mismo ejercicio usando solo `if/else`.

```nexis
int mes = Console.input(text="Mes (1-12): ")
string estacion

switch (mes) {
    case 12: case 1: case 2:
        estacion = "Verano"
        break
    case 3: case 4: case 5:
        estacion = "Otoño"
        break
    case 6: case 7: case 8:
        estacion = "Invierno"
        break
    case 9: case 10: case 11:
        estacion = "Primavera"
        break
    default:
        estacion = "Mes inválido"
}

Console.print(estacion)
```

**Versión con `if/else`:**

```nexis
if (mes == 12 || mes == 1 || mes == 2) {
    estacion = "Verano"
} else if (mes == 3 || mes == 4 || mes == 5) {
    estacion = "Otoño"
} else if (mes == 6 || mes == 7 || mes == 8) {
    estacion = "Invierno"
} else if (mes == 9 || mes == 10 || mes == 11) {
    estacion = "Primavera"
} else {
    estacion = "Mes inválido"
}
```

**Comparación:** con valores fijos y agrupados, `switch` es más legible.

## Qué debería romper (práctica de errores)

| # | Código incorrecto | Error esperado | Corrección |
|---|-------------------|----------------|------------|
| 1 | `else` sin `if` previo | NX90 (sintaxis) | añadir el `if` correspondiente |
| 2 | `if (edad >= 18):` sin la indentación correcta | NX90 (sintaxis) | indentar el bloque |
| 3 | `if (5) { ... }` | NX23 (condición no booleana) | usar una comparación: `if (x == 5)` |
| 4 | `if (edad = 18)` (asignación) | NX23 | usar `==` |
| 5 | `switch` sin `default` | ninguno (opcional) | agregar `default` como buena práctica |
| 6 | Dos `case` con el mismo valor | NX24 (caso duplicado) | unir los casos o eliminar el duplicado |
| 7 | Mezclar estilos: `if (cond):` con `}` | NX90 (sintaxis) | elegir un solo estilo |

---

# Guía 02 — Bucles

**Objetivo:** `while`, `do while`, `for`, `foreach`, `break`, `continue`.

## Ejercicios

### Ejercicio 1: Números del 1 al 20 con cada bucle

Imprime los números del 1 al 20 usando cada tipo de bucle que soporte Nexis.

```nexis
#/ Con FOR
for i in 1 .. 20 {
    Console.println(i)
}

#/ Con WHILE
int j = 1
while (j <= 20) {
    Console.println(j)
    j = j + 1
}

#/ Con DO WHILE
int k = 1
do {
    Console.println(k)
    k = k + 1
} while (k <= 20)
```

### Ejercicio 2: Serie 2/5, 5/9, 8/13, ...

Genera la serie 2/5, 5/9, 8/13, ... (12 términos), concatenando el resultado en una sola cadena.

```nexis
string serie = ""
int num = 2
int den = 5

for i in 0 .. 11 {
    serie = serie + num + "/" + den
    if (i < 11) {
        serie = serie + ", "
    }
    num = num + 3
    den = den + 4
}

Console.print(serie)
```

### Ejercicio 3: Suma de múltiplos de 5 menores a 50

```nexis
int suma = 0
for i in 0 .. 50 step 5 {
    suma = suma + i
}
Console.print("Suma de múltiplos de 5: " + suma)   // 275
```

### Ejercicio 4: Número primo

Verifica si un número es primo (bucle + condicional + corte anticipado con `break`).

```nexis
int n = Console.input(text="Número: ")
bool es_primo = true

if (n < 2) {
    es_primo = false
} else {
    for d in 2 .. int(math.sqrt(n)) {
        if (n % d == 0) {
            es_primo = false
            break   // corte anticipado
        }
    }
}

if (es_primo):
    Console.print("Es primo")
else:
    Console.print("No es primo")
```

### Ejercicio 5: Primos gemelos menores a 100

```nexis
func es_primo_func(int: n) -> bool {
    if (n < 2) {
        emit -> false
    }
    for d in 2 .. int(math.sqrt(n)) {
        if (n % d == 0) {
            emit -> false
        }
    }
    emit -> true
}

for p in 2 .. 99 {
    if (es_primo_func(p) && es_primo_func(p + 2)) {
        Console.println(fs"{p} y {p + 2} son gemelos")
    }
}
```

### Ejercicio 6: Factorial con bucle y recursión

Calcula el factorial de un número usando bucle y usando recursión (compara ambas rutas).

```nexis
#/ Con bucle
int n = Console.input(text="Número: ")
int fact = 1
for i in 2 .. n {
    fact = fact * i
}
Console.print("Factorial (bucle): " + fact)

#/ Con recursión
func factorial(int: m) -> int {
    if (m <= 1) {
        emit -> 1
    } else {
        emit -> m * factorial(m - 1)
    }
}
Console.print("Factorial (recursión): " + factorial(n))
```

### Ejercicio 7: π con la serie de Leibniz

Calcula π mediante la serie de Leibniz hasta que la diferencia entre dos términos sea menor a `10⁻¹⁵`.

```nexis
double pi = 0
double termino
double signo = 1
double denominador = 1

do {
    termino = signo / denominador
    pi = pi + termino
    signo = -signo
    denominador = denominador + 2
} while (math.abs(termino) > 1e-15)

Console.print(fs"π ≈ {pi * 4}")
```

### Ejercicio 8: Invertir dígitos de un número

```nexis
int n = Console.input(text="Número: ")
int invertido = 0

while (n > 0) {
    invertido = invertido * 10 + n % 10
    n = n / 10
}

Console.print("Invertido: " + invertido)
```

### Ejercicio 9: Sumar los dígitos de un número

```nexis
int n = Console.input(text="Número: ")
int suma = 0

while (n > 0) {
    suma = suma + n % 10
    n = n / 10
}

Console.print("Suma de dígitos: " + suma)
```

### Ejercicio 10: Bucle infinito controlado con `break`

Crea un bucle infinito intencional con `break` condicionado y valida que `break` corte solo el bucle interno cuando hay anidamiento.

```nexis
for i in 0 .. 3 {
    for j in 0 .. 9 {
        if (j == 2) {
            break   // solo corta el bucle interno
        }
        Console.println(fs"i={i} j={j}")
    }
    Console.println(fs"--- terminado interno para i={i}")
}
```

## Qué debería romper (práctica de errores)

| # | Código incorrecto | Error esperado | Corrección |
|---|-------------------|----------------|------------|
| 1 | `break` al nivel del programa (fuera de todo bucle) | NX20 | moverlo dentro de un bucle |
| 2 | `continue` fuera de un bucle | NX21 | moverlo dentro de un bucle |
| 3 | `for i in 0 .. 10 step 0` | NX22 (paso inválido) | usar `step` distinto de 0 |
| 4 | Bucle `while (i < 5)` sin actualizar `i` | NX42 (cuelga / timeout) | sumar `i = i + 1` |
| 5 | `foreach` agregando elementos a la misma colección | NX51 (modificar durante iteración) | construir otro vector |
| 6 | Modificar la variable de control del `for` dentro del cuerpo | comportamiento indefinido | declarar otra variable |

---

# Guía 03 — Funciones

**Objetivo:** funciones con y sin retorno, parámetros, alcance (scope), recursión.

## Ejercicios

### Ejercicio 1: `esPrimo(n)`

Función que devuelve booleano y lista primos menores a 100.

```nexis
#inject math;

func esPrimo(int: n) -> bool {
    if (n < 2) {
        emit -> false
    }
    for d in 2 .. int(math.sqrt(n)) {
        if (n % d == 0) {
            emit -> false
        }
    }
    emit -> true
}

for n in 2 .. 99 {
    if (esPrimo(n)) {
        Console.println(n)
    }
}
```

**Paso a paso:**
1. `if (n < 2)` descarta 0, 1 y negativos.
2. Se prueba la división con todos los divisores hasta `√n`.
3. `emit -> false` corta en cuanto encuentra un divisor.
4. La función retorna `true` solo si no encontró ningún divisor.

### Ejercicio 2: Factorial con retorno y versión sin retorno

```nexis
func factorial(int: n) -> int {
    if (n <= 1) {
        emit -> 1
    } else {
        emit -> n * factorial(n - 1)
    }
}

void imprimirFactorial(int: n) {
    Console.print("El factorial de " + n + " es " + factorial(n))
}

imprimirFactorial(6)   // El factorial de 6 es 720
```

### Ejercicio 3: Números de Sophie Germain

Función `esSophieGermain(p)` que reutiliza `esPrimo` (llamada de función dentro de función). Un primo `p` es de Sophie Germain si `2p + 1` también es primo.

```nexis
func esSophieGermain(int: p) -> bool {
    if (!esPrimo(p)) {
        emit -> false
    }
    emit -> esPrimo(2 * p + 1)
}
```

### Ejercicio 4: Raíz cuadrada por el método de Newton

```nexis
func raizNewton(float: x) -> float {
    float aprox = x / 2
    for i in 0 .. 50 {
        aprox = (aprox + x / aprox) / 2
    }
    emit -> aprox
}

Console.print(raizNewton(81.0))   // ≈ 9
```

### Ejercicio 5: Combinatorio `nCr`

Función `combinatorio(n, r)` que use funciones auxiliares `factorial()` (composición).

```nexis
func combinatorio(int: n, int: r) -> int {
    emit -> factorial(n) / (factorial(r) * factorial(n - r))
}
```

### Ejercicio 6: Coseno con la serie de Taylor

Función `calcularCoseno(x)` mediante la serie de Taylor con límite de términos.

```nexis
#inject math;

func potencia(float: base, int: exp) -> float {
    float r = 1
    for i in 1 .. exp {
        r = r * base
    }
    emit -> r
}

func calcularCoseno(float: x) -> float {
    float suma = 0
    for n in 0 .. 15 {
        float termino = potencia(-1, n) * potencia(x, 2 * n) / factorial(2 * n)
        suma = suma + termino
    }
    emit -> suma
}

Console.print(calcularCoseno(0.0))   // ≈ 1
```

### Ejercicio 7: Función que recibe y devuelve un vector

```nexis
#inject vector;

func duplicar(Vector<int>: lista) -> Vector<int> {
    Vector<int> resultado = []
    foreach (v in lista) {
        resultado.agregar(v * 2)
    }
    emit -> resultado
}

Vector<int> entrada = [1, 2, 3]
Vector<int> salida = duplicar(entrada)   // [2, 4, 6]
```

### Ejercicio 8: Fibonacci recursivo e iterativo

```nexis
func fib_rec(int: n) -> int {
    if (n <= 1) {
        emit -> n
    } else {
        emit -> fib_rec(n - 1) + fib_rec(n - 2)
    }
}

func fib_iter(int: n) -> int {
    if (n <= 1) {
        emit -> n
    }
    int a = 0
    int b = 1
    int c = 0
    for i in 2 .. n {
        c = a + b
        a = b
        b = c
    }
    emit -> c
}

Console.print(fs"rec: {fib_rec(10)} | iter: {fib_iter(10)}")   // 55 | 55
```

> **Comparación:** la versión iterativa es mucho más rápida; la recursiva es más corta pero puede llegar a NX92 si crece demasiado.

### Ejercicio 9: Alcance global vs local

Dos variables con el mismo nombre, una global y una local dentro de una función: ¿cuál gana?

```nexis
int valor = 100

void mostrar_valor() {
    int valor = 5
    Console.print("Local: " + valor)    // 5
}

mostrar_valor()
Console.print("Global: " + valor)       // 100
```

**Comportamiento de scope en Nexis:** la variable local (dentro de la función) es independiente de la global. Fuera de la función solo existe la global. Cuando hay dos variables con el mismo nombre, la **más cercana (local)** gana dentro del bloque.

### Ejercicio 10: Recursión sin caso base (error esperado)

Una función que se llama a sí misma sin caso base.

```nexis
func infinita() -> int {
    infinita()   // ERROR esperado: NX92 (desbordamiento de pila / memoria)
}
```

**Respuesta esperada:** NX92. La pila de llamadas crece sin límite y el programa aborta por `ErrorMemoria`.

## Qué debería romper (práctica de errores)

| # | Código incorrecto | Error esperado | Corrección |
|---|-------------------|----------------|------------|
| 1 | `suma(5)` cuando la firma es `func suma(int: a, int: b)` | NX32 (cantidad de argumentos) | pasar los dos argumentos |
| 2 | `suma(1, 2, 3)` | NX32 | quitar el argumento extra |
| 3 | Función `-> bool` sin `emit` en la rama `else` | NX30 (ruta sin retorno) | agregar `else { emit -> false }` |
| 4 | `func suma(...)` sin `-> int` | NX31 (falta tipo de retorno) | escribir `-> int` |
| 5 | `emit -> a + b` dentro de una función `void` | NX36 (sin embargo, en docs se describe como usar `void` + no `emit`) → documentado como error de diseño | eliminar `emit` |
| 6 | Dos funciones con el mismo nombre | NX34 (función duplicada) | renombrar una |
| 7 | `func f(int: a, int: a)` | NX35 (parámetro repetido) | renombrar el parámetro |
| 8 | Pasar un `string` donde se espera `int` | NX33 (tipo de argumento) | convertir con `int(...)` |

---

# Guía 04 — Manejo de errores (try/catch)

**Objetivo:** lanzar, capturar y propagar errores.

## Ejercicios

### Ejercicio 1: Capturar división por cero

Divide dos números leídos por teclado; captura el error de división entre cero y muestra un mensaje amigable.

```nexis
int a = Console.input(text="Dividendo: ")
int b = Console.input(text="Divisor: ")

try {
    int resultado = a / b
    Console.print("Resultado: " + resultado)
} catch (ErrorDivision e) {
    Console.print("No se puede dividir entre cero")
}
```

### Ejercicio 2: Capturar índice fuera de rango

```nexis
#inject vector;

Vector<int> datos = [10, 20, 30]
int indice = Console.input(text="Posición: ")

try {
    int valor = datos.obtener(indice)
    Console.print("Valor: " + valor)
} catch (ErrorIndice e) {
    Console.print("Índice fuera de rango")
}
```

### Ejercicio 3: Conversión inválida

```nexis
string texto = Console.input(text="Ingrese un número: ")

try {
    int valor = int(texto)
    Console.print("El doble es: " + (valor * 2))
} catch (ErrorValidacion e) {
    Console.print("El texto no es un número válido")
}
```

### Ejercicio 4: Múltiples `catch`

Un `try` con múltiples `catch` para distintos tipos de error.

```nexis
#inject vector;

try {
    Vector<int> datos = [10, 20]
    int pos = Console.input(text="Posición: ")
    int r = 100 / pos
    Console.print(datos.obtener(r))
} catch (ErrorIndice e) {
    Console.print("Índice fuera de rango")
} catch (ErrorDivision e) {
    Console.print("División por cero")
} catch (Error e) {
    Console.print("Error general: " + e.mensaje())
}
```

> El orden importa: los `catch` específicos van antes del genérico `Error`.

### Ejercicio 5: `try/catch/finally`

Verifica que el bloque `finally` se ejecute tanto si hay error como si no.

```nexis
try {
    int r = 10 / 0
} catch (ErrorDivision e) {
    Console.print("Hubo un error")
} finally {
    Console.print("Esto se ejecuta SIEMPRE")
}
```

### Ejercicio 6: Lanzar un error personalizado

```nexis
func validar_edad(int: edad) {
    if (edad < 0):
        lanzar ErrorValidacion("La edad no puede ser negativa")
    if (edad < 18):
        lanzar ErrorValidacion("Menor de edad no permitido")
    Console.print("Edad válida")
}

try {
    validar_edad(-5)
} catch (ErrorValidacion e) {
    Console.print("Rechazado: " + e.mensaje())
}
```

### Ejercicio 7: Errores anidados

```nexis
func nivel_interno() {
    lanzar ErrorIndice("fallo interno")
}

try {
    try {
        nivel_interno()
    } catch (Error e) {
        Console.print("Error interno capturado, propagando...")
        lanzar e   // relanzar al exterior
    }
} catch (Error e) {
    Console.print("Error externo: " + e.mensaje())
}
```

### Ejercicio 8: Error no capturado (documentar comportamiento)

Un error que no es capturado por ningún `catch`.

```nexis
int r = 10 / 0   // NX42
```

**Comportamiento de Nexis:** el programa **aborta su ejecución** y muestra el código de error (`NX01`), el mensaje, la línea y el archivo donde ocurrió.

## Qué debería romper (práctica de errores)

| # | Código incorrecto | Error esperado | Corrección |
|---|-------------------|----------------|------------|
| 1 | `catch (Error e)` sin `try` previo | NX40 | envolver en `try { }` |
| 2 | `try { } catch (Error e)` sin sentencias | NX41 (try vacío) | escribir el código que falla |
| 3 | `lanzar 5` | NX43 (no es un `Error`) | `lanzar ErrorValidacion("...")` |
| 4 | `lanzar "mensaje"` | NX43 | usar una clase de error |
| 5 | Cargar el `catch` general antes del específico | semántica (nunca llega el específico) | ordenar: específico primero |
| 6 | `afirmar(cond_falsa, "msg")` | NX44 (aserción fallida) | corregir la condición o los datos |

---

# Guía 05 — Estructuras de datos

**Objetivo:** vector, linked_list, stack, queue, map, set, tree, trie, graph — creación, inserción, borrado, recorrido.

## Ejercicios

### Ejercicio 1: Vector — ordenar, buscar, insertar y eliminar

```nexis
#inject vector;

Vector<int> datos = [5, 1, 4, 2, 3]
datos.ordenar()                     // [1, 2, 3, 4, 5]
bool existe = datos.contiene(3)     // true
datos.insertar(2, 99)               // [1, 2, 99, 3, 4, 5]
datos.eliminar(0)                   // [2, 99, 3, 4, 5]

foreach (v in datos) {
    Console.println(v)
}
```

### Ejercicio 2: Lista enlazada — inserciones y borrado por valor

```nexis
#inject linked_list;

LinkedList<int> lista = LinkedList()
lista.agregar_frente(3)
lista.agregar_frente(2)
lista.agregar_frente(1)    // 1 -> 2 -> 3

int primer = lista.eliminar_frente()
Console.print(fs"Eliminado: {primer}")   // 1
Console.print("Longitud: " + lista.longitud())   // 2
```

### Ejercicio 3: Pila — paréntesis balanceados

```nexis
#inject stack;

string expresion = Console.input(text="Expresión: ")

Stack<char> pila = Stack()
bool balanceado = true

foreach (caracter in expresion) {
    if (caracter == '(') {
        pila.apilar(caracter)
    } else if (caracter == ')') {
        if (pila.esta_vacia()) {
            balanceado = false
            break
        } else {
            pila.desapilar()
        }
    }
}

if (balanceado && pila.esta_vacia()) {
    Console.print("Paréntesis balanceados")
} else {
    Console.print("Paréntesis NO balanceados")
}
```

### Ejercicio 4: Cola — fila de atención (FIFO)

```nexis
#inject queue;

Queue<int> fila = Queue()
fila.encolar(101)
fila.encolar(102)
fila.encolar(103)

while (!fila.esta_vacia()) {
    int turno = fila.desencolar()
    Console.println(fs"Atendiendo turno {turno}")
}
```

### Ejercicio 5: Mapa — frecuencia de palabras

```nexis
#inject map;
#inject string;

string frase = "el gato y el perro y el gato"
Vector<string> palabras = string.dividir(frase, " ")

Map<string, int> frecuencia = {}
foreach (palabra in palabras) {
    if (frecuencia.contiene(palabra)) {
        frecuencia.poner(palabra, frecuencia.obtener(palabra) + 1)
    } else {
        frecuencia.poner(palabra, 1)
    }
}

Console.print("Frecuencia de 'el': " + frecuencia.obtener("el"))   // 3
```

### Ejercicio 6: Conjunto — unión, intersección y diferencia

```nexis
#inject set;

Set<int> a = {1, 2, 3, 4}
Set<int> b = {3, 4, 5, 6}

Set<int> union = {}
foreach (v in a) { union.agregar(v) }
foreach (v in b) { union.agregar(v) }

Set<int> interseccion = {}
foreach (v in a) {
    if (b.contiene(v)) {
        interseccion.agregar(v)
    }
}

Set<int> diferencia = {}
foreach (v in a) {
    if (!b.contiene(v)) {
        diferencia.agregar(v)
    }
}

Console.print(fs"Unión: {union.longitud()} | Intersección: {interseccion.longitud()} | Diferencia: {diferencia.longitud()}")
```

### Ejercicio 7: Árbol binario — inserción y recorrido in-order

```nexis
#inject tree;

Tree<int> arbol = Tree()
arbol.insertar(50)
arbol.insertar(30)
arbol.insertar(70)
arbol.insertar(20)
arbol.insertar(40)
arbol.insertar(60)
arbol.insertar(80)

arbol.en_orden()   // 20, 30, 40, 50, 60, 70, 80
bool ok = arbol.buscar(40)   // true
```

### Ejercicio 8: Trie — inserción y validación de prefijos

```nexis
#inject trie;

Trie diccionario = Trie()
diccionario.insertar("programa")
diccionario.insertar("programacion")
diccionario.insertar("programador")

bool prefijo = diccionario.comienza_con("pro")     // true
bool palabra = diccionario.contiene("programar")   // false (no está)
```

### Ejercicio 9: Grafo — BFS y DFS

```nexis
#inject graph;

Graph<string> grafo = Graph()
grafo.agregar_nodo("A")
grafo.agregar_nodo("B")
grafo.agregar_nodo("C")
grafo.agregar_nodo("D")
grafo.agregar_nodo("E")
grafo.conectar("A", "B", 1)
grafo.conectar("A", "C", 1)
grafo.conectar("B", "D", 1)
grafo.conectar("C", "E", 1)

grafo.recorrido_anchura("A")        // BFS
grafo.recorrido_profundidad("A")    // DFS
```

### Ejercicio 10: Palíndromo con pila y cola

```nexis
#inject stack;
#inject queue;

string texto = Console.input(text="Texto: ")
Stack<char> pila = Stack()
Queue<char> cola = Queue()

foreach (c in texto) {
    if (c != ' ') {
        pila.apilar(c)
        cola.encolar(c)
    }
}

bool palindromo = true
while (!pila.esta_vacia()) {
    if (pila.desapilar() != cola.desencolar()) {
        palindromo = false
        break
    }
}

if (palindromo):
    Console.print("Es palíndromo")
else:
    Console.print("No es palíndromo")
```

## Qué debería romper (práctica de errores)

| # | Código incorrecto | Error esperado | Corrección |
|---|-------------------|----------------|------------|
| 1 | `pila.desapilar()` con la pila vacía | NX50 (colección vacía) | verificar `esta_vacia()` |
| 2 | `nums.obtener(-1)` o `nums.obtener(99)` | NX11 (índice fuera de rango) | validar contra `longitud()` |
| 3 | Recorrer un grafo con ciclos sin marcar visitados | bucle infinito (relacionado con NX42) | marcar nodos visitados |
| 4 | Vector con tipos mixtos `[1, "dos"]` | NX07 (tipo) | mantener un solo tipo |
| 5 | Borrar nodos mientras se itera una lista | NX51 (modificar durante iteración) | construir una nueva lista |

---

# Guía 06 — Librerías estándar

**Objetivo:** `math`, `string`, `random`, `time`, `file`, `graphics`, `network`.

## Ejercicios

### Ejercicio 1: math — potencia, raíz, logaritmo y valor absoluto

```nexis
#inject math;

float base = Console.input(text="Base: ")
float expo = Console.input(text="Exponente: ")

Console.print("Potencia: " + math.pow(base, expo))
Console.print("Raíz cuadrada: " + math.sqrt(base))
Console.print("Logaritmo natural: " + math.log(base))
Console.print("Valor absoluto: " + math.abs(-expo))
```

### Ejercicio 2: string — vocales, mayúsculas, invertir y palíndromo

```nexis
#inject string;

string frase = Console.input(text="Frase: ")

int vocales = 0
foreach (c in frase) {
    c = string.minusculas(string(c))
    if (c == "a" || c == "e" || c == "i" || c == "o" || c == "u") {
        vocales = vocales + 1
    }
}
Console.print("Vocales: " + vocales)

string mayus = string.mayusculas(frase)
Console.print("Mayúsculas: " + mayus)

string invertida = string.dividir(frase, " ")[(string.dividir(frase, " ").longitud() - 1)]
// o invierte manualmente con un bucle
```

### Ejercicio 3: random — lanzar un dado 100 veces

```nexis
#inject random;

Vector<int> conteos = [0, 0, 0, 0, 0, 0]

for i in 0 .. 99 {
    int cara = random.entero(1, 6)
    conteos[cara - 1] = conteos[cara - 1] + 1
}

for i in 0 .. 5 {
    Console.println(fs"Cara {i + 1}: {conteos[i]}")
}
```

### Ejercicio 4: time — medir el tiempo de un cálculo

```nexis
#inject time;
#inject vector;

auto inicio = time.reloj()

int fact = 1
for i in 1 .. 20 {
    fact = fact * i
}

int duracion = time.reloj() - inicio
Console.print(fs"Factorial de 20 calculado en {duracion} ms")
```

### Ejercicio 5: file — escribir y leer una lista de números

```nexis
#inject file;

string contenido = "" 
for i in 1 .. 10 {
    contenido = contenido + i
    if (i < 10) {
        contenido = contenido + "\n"
    }
}
file.escribir("numeros.txt", contenido)

string leido = file.leer("numeros.txt")

#/ Calcular el promedio de los números leídos
Vector<string> lineas = string.dividir(leido, "\n")
float suma = 0
foreach (linea in lineas) {
    suma = suma + float(linea)
}
Console.print("Promedio: " + (suma / lineas.longitud()))   // 5.5
```

### Ejercicio 6: graphics — dibujar un cuadrado y un círculo

```nexis
#inject graphics;

graphics.crear_ventana(800, 600, "Primer dibujo")
graphics.limpiar("negro")
graphics.rectangulo(300, 250, 200, 150, "azul")   #/ cuadrado/rectángulo
graphics.punto(400, 300, "rojo")
graphics.mostrar()
#/ La ventana permanece hasta que se cierra
```

> En la versión demo `graphics` está planificada; el ejemplo muestra la API prevista.

### Ejercicio 7: network — petición simple

```nexis
#inject network;

try {
    auto respuesta = network.get("https://nexis.dev/api/version")
    Console.print("Estado: " + respuesta.estado)
    Console.print("Cuerpo: " + respuesta.cuerpo)
} catch (ErrorRed e) {
    Console.print("No se pudo conectar: " + e.mensaje())
}
```

### Ejercicio 8: Combinado — aleatorios, archivo y estadísticas

```nexis
#inject math;
#inject random;
#inject file;

Vector<float> valores = []
for i in 0 .. 19 {
    valores.agregar(random.decimal(0, 100))
}

string contenido = ""
foreach (v in valores) {
    contenido = contenido + string(v) + "\n"
}
file.escribir("aleatorios.txt", contenido)

string leido = file.leer("aleatorios.txt")
float suma = 0
foreach (linea in string.dividir(leido, "\n")) {
    suma = suma + float(linea)
}
float media = suma / 20

Console.print("Media: " + media)
```

## Qué debería romper (práctica de errores)

| # | Código incorrecto | Error esperado | Corrección |
|---|-------------------|----------------|------------|
| 1 | `#inject mate;` | NX80 (módulo no encontrado) | escribir `#inject math;` |
| 2 | `math.sqrt(81)` sin `#inject math;` | NX82 (función sin importar) | agregar la importación |
| 3 | `file.leer("no_existe.txt")` | NX61 (archivo no encontrado) | verificar con `file.existe` |
| 4 | `math.raiz("hola")` | NX33 o NX12 (tipo/argumento inválido) | pasar un `float` |
| 5 | `math.sqrt(-4)` | NX13 (operación inválida) | validar el argumento |
| 6 | Dos librerías con la misma función sin calificar | NX82 / ambigüedad | calificar con `libreria.funcion()` |

---

# Guía 07 — Módulos e importación

**Objetivo:** separar código en varios archivos y su importación con `#inject`.

## Prepara los módulos

### Módulo `geometria.nex`

```nexis
#/ geometria.nex
#inject math;

func areaCirculo(float: radio) -> float {
    emit -> math.PI * radio * radio
}

func areaCuadrado(float: lado) -> float {
    emit -> lado * lado
}

func areaTriangulo(float: base, float: altura) -> float {
    emit -> (base * altura) / 2
}
```

### Ejercicio 1: Importar el módulo desde un programa principal

```nexis
#/ principal.nex
#inject "geometria.nex";

Console.print(areaCirculo(5.0))
Console.print(areaCuadrado(4.0))
Console.print(areaTriangulo(3.0, 2.0))
```

**Paso a paso:**
1. Guarda `geometria.nex` en la misma carpeta que `principal.nex`.
2. Importa con `#inject "geometria.nex";` (ruta y extensión).
3. Llama a las funciones directamente.

### Ejercicio 2: Importar una librería que usa otra (propagación)

Un módulo que importa `math` y expone una función que la usa:

```nexis
#/ superficies.nex
#inject math;

func circunferencia(float: radio) -> float {
    emit -> 2 * math.PI * radio
}
```

```nexis
#/ app.nex
#inject "superficies.nex";

Console.print(circunferencia(5.0))   // funciona: math se importó en superficies
```

### Ejercicio 3: Dos módulos que se importan mutuamente (documentar)

```nexis
#/ a.nex
#inject "b.nex";

#/ b.nex
#inject "a.nex";
```

**Comportamiento esperado:** NX81 (importación circular). Nexis no puede ordenar las dependencias. **Solución:** extraer las funciones compartidas a un módulo `comun.nex` que ambos importen, rompiendo el ciclo.

### Ejercicio 4: Importar el mismo módulo dos veces

```nexis
#inject "geometria.nex";
#inject "geometria.nex";
```

**Comportamiento:** Nexis detecta que el módulo ya se importó y **lo ignora** (no se ejecuta dos veces). No genera error, pero es más limpio importar una sola vez.

### Ejercicio 5: Dos funciones con el mismo nombre en dos módulos

```nexis
#/ mod_a.nex
func saludo() -> string {
    emit -> "Hola desde A"
}

#/ mod_b.nex
func saludo() -> string {
    emit -> "Hola desde B"
}

#/ app.nex
#inject "mod_a.nex";
#inject "mod_b.nex";

Console.print(saludo())   // ambigüedad: ¿cuál gana?
```

**Comportamiento esperado:** error de ambigüedad o gana el último importado (depende de la versión). **Recomendación:** no definas funciones con el mismo nombre en módulos distintos; prefija los nombres (`saludo_a`, `saludo_b`) o usa nombres de módulo en las llamadas cuando el lenguaje lo permita.

## Qué debería romper (práctica de errores)

| # | Código incorrecto | Error esperado | Corrección |
|---|-------------------|----------------|------------|
| 1 | `#inject "no_existe.nex";` | NX80 (módulo no encontrado) | crear el archivo o corregir la ruta |
| 2 | Importación circular A ↔ B | NX81 | usar un módulo común `comun.nex` |
| 3 | Usar `areaCirculo()` sin importar | NX82 (función sin importar) | agregar `#inject "geometria.nex";` |
| 4 | Importar con nombre mal escrito `#inject geometria;` | NX80 | usar la ruta completa `"geometria.nex"` |

---

# Guía 08 — Proyecto integrador: agenda de contactos

**Objetivo:** construir una aplicación completa que use casi todas las construcciones del lenguaje: structs, vectores, menú con bucles, condicionales, `switch`, try/catch, clasificación y archivos.

## Enunciado

Construye una **agenda de contactos** en Nexis que:

1. Guarde contactos (nombre, teléfono, categoría) en un `Vector` de structs.
2. Permita agregar, buscar, editar y eliminar contactos mediante un menú con `while` + `switch`.
3. Valide los datos de entrada (teléfono numérico, nombre no vacío) usando `try/catch`.
4. Ordene los contactos alfabéticamente usando una función propia.
5. Guarde y cargue la agenda desde un archivo (`file`).
6. Muestre estadísticas con `math` (cuántos contactos por categoría).

## Solución paso a paso

### Paso 1: Definir el struct de contacto

```nexis
struct Contacto {
    string nombre
    string telefono
    string categoria
}
```

### Paso 2: Funciones de utilidad

```nexis
#inject vector;
#inject file;
#inject string;
#inject math;

func nombre_valido(string: nombre) -> bool {
    emit -> string.longitud(nombre) > 0
}

func telefono_valido(string: telefono) -> bool {
    bool valido = true
    foreach (d in telefono) {
        if (d < '0' || d > '9') {
            valido = false
            break
        }
    }
    emit -> string.longitud(telefono) > 0 && valido
}

Contacto nuevo_contacto(string: nombre, string: telefono, string: categoria) -> Contacto {
    Contacto c = Contacto()
    c.nombre = nombre
    c.telefono = telefono
    c.categoria = categoria
    emit -> c
}
```

### Paso 3: Agregar contacto con validación

```nexis
void agregar_contacto(Vector<Contacto>*) -> Contacto    #/ notación reservada
```

> **Nota:** Nexis (versión demo) no documenta paso de referencias de vectores. En su lugar, la agenda se maneja en el `main` con funciones de módulo que reciben y devuelven el vector. A continuación se muestra el programa completo simplificado con las operaciones en el cuerpo principal.

### Paso 4: Programa principal

```nexis
#inject vector;
#inject file;
#inject string;
#inject math;

struct Contacto {
    string nombre
    string telefono
    string categoria
}

bool nombre_valido(string: nombre) -> bool {
    emit -> string.longitud(nombre) > 0
}

bool telefono_valido(string: telefono) -> bool {
    bool valido = true
    foreach (d in telefono) {
        if (d < '0' || d > '9') {
            valido = false
            break
        }
    }
    emit -> string.longitud(telefono) > 0 && valido
}

#/ Ordenar contactos alfabéticamente (inserción simple)
void ordenar_contactos(Vector<Contacto>: agenda) {
    for i in 1 .. agenda.longitud() - 1 {
        int j = i
        while (j > 0 && agenda.obtener(j).nombre < agenda.obtener(j - 1).nombre) {
            Contacto temp = agenda.obtener(j)
            agenda.asignar(j, agenda.obtener(j - 1))
            agenda.asignar(j - 1, temp)
            j = j - 1
        }
    }
}

#/ Guardar la agenda en un archivo
void guardar(Vector<Contacto>: agenda) {
    string contenido = ""
    foreach (contacto in agenda) {
        contenido = contenido + contacto.nombre + ";" + contacto.telefono + ";" + contacto.categoria + "\n"
    }
    file.escribir("agenda.txt", contenido)
}

Vector<Contacto> cargar() {
    Vector<Contacto> agenda = []
    if (file.existe("agenda.txt")) {
        string contenido = file.leer("agenda.txt")
        Vector<string> lineas = string.dividir(contenido, "\n")
        foreach (linea in lineas) {
            if (string.longitud(linea) > 0) {
                Vector<string> partes = string.dividir(linea, ";")
                Contacto c = Contacto()
                c.nombre = partes.obtener(0)
                c.telefono = partes.obtener(1)
                c.categoria = partes.obtener(2)
                agenda.agregar(c)
            }
        }
    }
    emit -> agenda
}

void mostrar_agenda(Vector<Contacto>: agenda) {
    foreach (contacto in agenda) {
        Console.println(fs"{contacto.nombre} | {contacto.telefono} | {contacto.categoria}")
    }
}

#/ ---------- PROGRAMA PRINCIPAL ----------
Vector<Contacto> agenda = cargar()
int opcion

do {
    Console.println("--- AGENDA DE CONTACTOS ---")
    Console.println("1. Agregar contacto")
    Console.println("2. Buscar contacto")
    Console.println("3. Editar contacto")
    Console.println("4. Eliminar contacto")
    Console.println("5. Listar y ordenar")
    Console.println("6. Estadísticas")
    Console.println("7. Guardar y salir")

    opcion = Console.input(text="Opción: ")

    switch (opcion) {
        case 1:
            string nombre = Console.input(text="Nombre: ")
            string telefono = Console.input(text="Teléfono: ")
            string categoria = Console.input(text="Categoría: ")

            try {
                if (!nombre_valido(nombre)) {
                    lanzar ErrorValidacion("El nombre no puede estar vacío")
                }
                if (!telefono_valido(telefono)) {
                    lanzar ErrorValidacion("El teléfono debe ser numérico")
                }
                Contacto c = Contacto()
                c.nombre = nombre
                c.telefono = telefono
                c.categoria = categoria
                agenda.agregar(c)
                Console.print("Contacto agregado")
            } catch (ErrorValidacion e) {
                Console.print("Datos inválidos: " + e.mensaje())
            }
        break

        case 2:
            string clave = Console.input(text="Nombre a buscar: ")
            bool encontrado = false
            foreach (contacto in agenda) {
                if (contacto.nombre == clave) {
                    Console.println(fs"{contacto.nombre} | {contacto.telefono} | {contacto.categoria}")
                    encontrado = true
                }
            }
            if (!encontrado) {
                Console.print("No encontrado")
            }
        break

        case 3:
            string original = Console.input(text="Nombre del contacto a editar: ")
            foreach (contacto in agenda) {
                if (contacto.nombre == original) {
                    contacto.telefono = Console.input(text="Nuevo teléfono: ")
                    contacto.categoria = Console.input(text="Nueva categoría: ")
                }
            }
        break

        case 4:
            string borrar = Console.input(text="Nombre a eliminar: ")
            Vector<Contacto> nueva = []
            foreach (contacto in agenda) {
                if (contacto.nombre != borrar) {
                    nueva.agregar(contacto)
                }
            }
            agenda = nueva
        break

        case 5:
            ordenar_contactos(agenda)
            mostrar_agenda(agenda)
        break

        case 6:
            Map<string, int> conteo = {}
            foreach (contacto in agenda) {
                if (conteo.contiene(contacto.categoria)) {
                    conteo.poner(contacto.categoria, conteo.obtener(contacto.categoria) + 1)
                } else {
                    conteo.poner(contacto.categoria, 1)
                }
            }
            string mas_comun = ""
            int maximo = 0
            foreach (par in conteo) {
                if (par.valor > maximo) {
                    maximo = par.valor
                    mas_comun = par.clave
                }
            }
            Console.print("Total de contactos: " + agenda.longitud())
            Console.print("Categoría más común: " + mas_comun)
        break

        case 7:
            guardar(agenda)
            Console.print("Agenda guardada. ¡Hasta luego!")
        break

        default:
            Console.print("Opción inválida")
    }
} while (opcion != 7)
```

**Qué valida este proyecto:** structs, vectores, menú con `do while`, `switch`, `try/catch`, entrada/salida, archivos, ordenamiento propio, mapas para estadísticas y todas las librerías principales. Si alguna construcción no tiene regla clara (por ejemplo, cómo recorrer un `Map` con `foreach` en tu versión), anótalo y ajusta el ejemplo.

---

## Guía 09 — Práctica de errores avanzada

**Objetivo:** reforzar la identificación y solución de errores combinando múltiples códigos NX.

### Ejercicio 1: Encuentra todos los errores

El siguiente programa tiene al menos 5 errores. Anota el código NX de cada uno y corrígelos.

```nexis
int preció = 10
int x
const double IVA
int resultado = "20" + 5

iva = 0.18
Console.print(x)
```

**Errores y soluciones:**

| # | Línea | Error NX | Corrección |
|---|-------|----------|------------|
| 1 | `int preció = 10` | NX05 (identificador inválido) | `int precio = 10` |
| 2 | `const double IVA` | NX06 (constante sin inicializar) | `const double IVA = 0.18` |
| 3 | `int resultado = "20" + 5` | NX10 (operandos incompatibles) | `int resultado = int("20") + 5` |
| 4 | `iva = 0.18` | NX02 (variable no definida) o NX03 (si era la constante) | `IVA = 0.18` en la declaración |
| 5 | `Console.print(x)` | NX00 (variable no inicializada) | `int x = 0` |

### Ejercicio 2: Corrige sin ejecutar

Sin ejecutar el programa, decide qué salida o error produce:

```nexis
func f(int: a, int: b) -> bool {
    a > b
}

bool r = f(3)
```

**Respuesta:** NX32 (cantidad de argumentos incorrecta: se esperan 2 y se pasó 1).

### Ejercicio 3: Depura el error de archivo

```nexis
#inject file;

string contenido = file.leer("reporte_final.txt")
Console.print(contenido)
```

**Respuesta:** NX61 si `reporte_final.txt` no existe. Solución: comprobar `file.existe("reporte_final.txt")` antes de leer, o crear el archivo antes.

### Ejercicio 4: Clasifica los errores por categoría

Ordena los siguientes errores en su categoría correcta y explica cada uno brevemente:
`NX42`, `NX92`, `NX12`, `NX44`, `NX81`, `NX24`.

**Respuesta:**
- `NX42` — Manejo de errores: excepción no capturada.
- `NX92` — Sistema: desbordamiento de pila/memoria.
- `NX12` — Tipos: conversión de tipo inválida.
- `NX44` — Manejo de errores: aserción fallida.
- `NX81` — Módulos: importación circular.
- `NX24` — Control de flujo: caso duplicado en `switch`.

---

## Sugerencias para mantener la disciplina de errores

1. **Anota el código NX** antes de corregir: te obliga a identificar la categoría del error.
2. **Lee el mensaje completo:** línea, archivo, variable involucrada.
3. **Soluciona la causa raíz, no el síntoma:** si el error viene de una entrada, valídala en lugar de ignorarla.
4. **Vuelve a ejecutar tras cada corrección** para confirmar que el error desapareció y no se crearon otros.
5. Usa la tabla de cada guía como **lista de control**: cuando domines todos los errores de una guía, avanza.