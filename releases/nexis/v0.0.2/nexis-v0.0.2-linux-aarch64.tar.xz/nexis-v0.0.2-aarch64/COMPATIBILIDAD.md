# Compatibilidad — Nexis vv0.0.2 (demo)

> Este instalador es una **demo de desarrollo** del lenguaje Nexis. No es una
> versión estable: compilador, intérprete, docs y extensión siguen en
> construcción y **no cubren el 100 % de la documentación** aún.

## Componentes incluidos

| Componente | Versión empaquetada | Estado |
|---|---|---|
| **Nexis** (producto completo) | vv0.0.2 | demo / en desarrollo |
| **Compilador** (`nexisc`) | vv0.0.2 | demo. Paridad 1:1 con el intérprete, pero no llega al 100 % del docs |
| **Intérprete** (`nexisi`) | vv0.0.2 | demo. Mismas salidas y errores que `nexisc`, no llega al 100 % del docs |
| **Docs** (base del lenguaje) | vvv0.0.2 | Base. Contiene incoherencias que se corregirán en v0.0.2 |
| **Extensión de VS Code** | vv0.0.2 | Soporte **parcial** de palabras reservadas; no funciona al 100 % con el docs |

## Limitantes actuales de la v0.0.1 (demo)

- **Sin** control de flujo (`if`/`while`/`for`), funciones, POO (structs/clases),
  `try`/`catch` ni módulos reales (`#inject` es `no-op`).
- Lenguaje actual: tipos primitivos (`int`, `float`, `double`, `char`,
  `string`, `bool`), variables y constantes, operadores, asignaciones compuestas
  y consola (`Console.print`, `Console.println`, `Console.input`).
- La **extensión** solo resalta parte de la sintaxis del docs.
- La **docs v0.0.1** sirve de base; la **v0.0.2** (en construcción) corregirá
  incoherencias y traerá el **soporte total** de docs, extensión, compilador e
  intérprete.

## Garantías

- `nexisc` y `nexisi` (modos archivo y `--bytecode`) producen **las mismas
  salidas y errores** — lo verifica `interpreter/scripts/run_interpreter_tests.sh`.

## Cómo saber si es demo

Todas las versiones usan el **prefijo `demo`** hasta que se considere estable:
ejecuta `nexisc --version` o `nexisi --version` y verás `0.0.1 (Nexis)` — el
producto completo se marcará formalmente al publicarse Nexis V1.0.0.