# Plan de Corrección — Documentación NEXIS v0.0.2

Análisis completo de errores en `prueba.md`, anomalias en la documentacion, y contradicciones entre el compilador/interprete y lo documentado.

---

## 1. Estado actual de los errores reportados en `prueba.md`

| # | Incidencia | Estado real (compilador v0.0.2) | Veredicto |
|---|------------|--------------------------------|-----------|
| 02 | Variable sin inicializar | **CORREGIDO** — `nexisc`/`nexisi` emiten `error[NX00]: Uninitialized variable` de forma consistente | OK |
| 03 | Caracter `%` en `Console.print()` | **CORREGIDO** — salida limpia, sin caracteres extra | OK |
| 04 | Validacion del punto y coma | **NO CORREGIDO** — `int x` sin `;` compila sin error | ABIERTO |
| 10 | `add()` en bucles + condicionales | **NO CORREGIDO** — vector queda `[]` porque `Console.input` devuelve `String` y la variable no inicializada pierde su tipo | ABIERTO |
| 11 | Declaracion de estructuras con tipo explicito | **NO CORREGIDO** — depende de la correccion del `;` | ABIERTO |
| 15 | Soporte `struct` | **NO CORREGIDO** — `Contacto()` sin argumentos falla (NX32), `.` para campos no esta en la gramatica (NX90) | ABIERTO |

### Raiz del error #10 (importante)

Cuando se declara `int nota` sin inicializar, el compilador no registra la variable en runtime. Al hacer `nota = Console.input(...)`, el tipo se pierde (`Type::Unknown`) y el valor se almacena como `String`. Esto hace que `nota <= 20` sea siempre `false` (comparacion string vs int), por lo que `notas.add(nota)` nunca se ejecuta.

---

## 2. Inconsistencias encontradas en la documentacion (21 errores)

### A. Enlaces rotos o intercambiados

| Archivo | Linea | Error | Correccion |
|---------|-------|-------|------------|
| `docs/README.md` | 31 | Dice "Funciones con retorno" pero enlaza a `funtions.md` (que es "sin retorno") | Intercambiar labels |
| `docs/README.md` | 32 | Dice "Funciones sin retorno" pero enlaza a `return-values.md` (que es "con retorno") | Intercambiar labels |
| `docs/language/variables/input-output.md` | 11 | Ruta `../operadores/operadores.md` no existe | Cambiar a `../operators/operadores.md` |
| `docs/language/operators/operadores.md` | 7 | Ruta `../README.md` apunta a `docs/language/README.md` (no existe) | Cambiar a `../../README.md` |

### B. Reglas contradictorias

| Archivo | Linea | Error | Correccion |
|---------|-------|-------|------------|
| `docs/language/variables/declaration.md` | 10, 15 | Dice que declaracion lleva `;` pero TODOS los ejemplos del archivo y del resto de docs omiten el `;` | Decidir: `;` obligatorio o no, y actualizar TODO consistentemente |
| `docs/language/functions/return-values.md` | 23-24 | Dice que `emit ->` es solo para bloques multi-linea | Coherente internamente pero contradice `funtions.md` |
| `docs/language/operators/operadores.md` | 186-187 | Operador ternario `=> ... <-->` listado DESPUES de asignacion (precedencia 10), pero se usa como expresion que asigna | Mover ternario ANTES de asignacion (precedencia ~3-4) |

### C. Caos de nombres Espanol/Ingles en metodos de colecciones

**El lenguaje NO define cual es el nombre real.** Los docs dicen una cosa en headers y otra en codigo:

| Estructura | Header (espanol) | Codigo (ingles) | `data-struture.md` | Metodo real en codigo fuente |
|------------|-------------------|------------------|--------------------|-----------------------------|
| Vector | `agregar` | `add` | `add` | `add` |
| Vector | `obtener` | `get` | `get` | `get` |
| Vector | `eliminar` | `remove` | `remove` | `remove` |
| Vector | `ordenar` | `sort` | `sort` | `sort` |
| Vector | `longitud` | `length` | — | `length` |
| Vector | `esta_vacio` | `isEmpty` | — | `isEmpty` |
| Stack | `apilar` | `push` | `push` | `push` |
| Stack | `desapilar` | `pop` | `pop` | `pop` |
| Stack | `cima` | `cima` | `peek` | `peek` |
| Queue | `encolar` | `enqueue` | `enqueue` | `enqueue` |
| Queue | `desencolar` | `dequeue` | `dequeue` | `dequeue` |
| Queue | `frente` | — | `front` | `front` |
| Map | `poner` | `put` | `put` | `put` |
| Map | `obtener` | `get` | `get` | `get` |
| Map | `contiene` | `contains` | `contains` | `contains` |

**Accion:** Usar nombres ingleses (que son los que el codigo implementa) en headers, codigo y tablas.

### D. Otros errores

| Archivo | Linea | Error | Correccion |
|---------|-------|-------|------------|
| `docs/language/control-flow/loops.md` | 1 | Resto de prompt de IA: "Entendido. Aqui tienes la version revisada..." | Eliminar esa linea |
| `docs/language/poo/structs.md` | 17, 22 | Dice "no se asignan valores en la definicion" pero luego llama `Contacto()` sin argumentos | Documentar constructor correcto o cambiar ejemplo |
| `docs/language/poo/classes.md` | 13, 25 | Template muestra `-> retorno` para todos los metodos, pero ejemplo usa `void` | Actualizar template para incluir `void` |
| `docs/language/errors/try_catch.md` | 150 | Usa `vector traza` (sin tipo) pero todas las colecciones deben ser tipadas `Vector<T>` | Cambiar a `Vector<string> traza` |
| `docs/language/data-types/data-struture.md` | 15 | Usa nombres ingleses para Map (`put`, `get`) pero `map.md` documenta en espanol | Unificar |

---

## 3. Plan de accion para corregir TODO (priorizado)

### FASE 1: Decidir las convenciones del lenguaje (ANTES de tocar docs)

Necesitas responder estas preguntas antes de corregir:

1. **Punto y coma:** `;` es obligatorio solo en declaraciones sin inicializar, en todas, o en ninguna?
   - El compilador actual NO valida `;` en ningun caso
   - `declaration.md` dice que si es obligatorio en declaraciones
   - Los ejemplos nunca lo usan
   - **Recomendacion:** Hacer `;` OPCIONAL en todo (como Python/Rust moderno) para consistencia con el comportamiento actual

2. **Nombres de metodos:** Espanol o Ingles?
   - El codigo fuente usa ingles (`add`, `get`, `remove`, `push`, `pop`, etc.)
   - **Recomendacion:** InglES en toda la documentacion (metodos, errores, mensajes)

3. **Struct:** Como se instancia?
   - `Contacto()` sin argumentos no funciona (NX32: espera 3 campos)
   - `Contacto(nombre, telefono, categoria)` si funciona
   - El operador `.` para campos no esta en la gramatica (NX90)
   - **Recomendacion:** Documentar `Contacto(arg1, arg2, arg3)` y agregar soporte para `.` en el parser

### FASE 2: Corregir la documentacion (14 archivos)

| Prioridad | Archivo | Cambios |
|-----------|---------|---------|
| 1 | `docs/README.md` | Intercambiar labels lineas 31-32 |
| 2 | `docs/language/variables/declaration.md` | Unificar regla de `;` (decidir en FASE 1), alinear ejemplos |
| 3 | `docs/language/variables/input-output.md` | Corregir ruta linea 11: `../operators/operadores.md` |
| 4 | `docs/language/operators/operadores.md` | Corregir ruta linea 7, mover precedencia ternario |
| 5 | `docs/language/control-flow/loops.md` | Eliminar linea 1 (resto de IA) |
| 6 | `docs/standard-library/collections/vector.md` | Renombrar todos los headers a ingles |
| 7 | `docs/standard-library/collections/stack.md` | Renombrar headers y tabla a ingles |
| 8 | `docs/standard-library/collections/queue.md` | Renombrar headers y tabla a ingles |
| 9 | `docs/standard-library/collections/map.md` | Renombrar headers a ingles |
| 10 | `docs/language/data-types/data-struture.md` | Verificar consistencia con metodos reales |
| 11 | `docs/language/poo/structs.md` | Corregir ejemplo de instanciacion y acceso a campos |
| 12 | `docs/language/poo/classes.md` | Actualizar template para incluir `void` |
| 13 | `docs/language/errors/try_catch.md` | Cambiar `vector traza` a `Vector<string> traza` |
| 14 | `docs/language/functions/return-values.md` | Verificar que la regla de `emit` no contradiga otros docs |

### FASE 3: Corregir el codigo fuente (compilador/interprete)

| Prioridad | Bug | Archivos a modificar |
|-----------|-----|---------------------|
| 1 | Falta validacion de `;` (issue #04) | `compiler/crates/nexis_parser/src/lib.rs` |
| 2 | `Console.input` no preserva tipo de variable (issue #10) | `compiler/crates/nexis_codegen/src/lib.rs` + `interpreter/nexis_vm/src/evaluator.rs` |
| 3 | `struct` no acepta constructor sin args (issue #15) | `compiler/crates/nexis_parser/src/lib.rs` + `compiler/crates/nexis_codegen/src/lib.rs` |
| 4 | Operador `.` no soportado para campos de struct (issue #15) | `compiler/crates/nexis_parser/src/lib.rs` |

### FASE 4: Agregar pruebas de regresion

Crear archivos `.nxs` en `tests/` para cada caso corregido:

```
tests/
  regression/
    01_semecolon_validation.nxs      # issue #04
    02_variable_type_preservation.nxs # issue #10
    03_struct_construction.nxs       # issue #15
    04_struct_field_access.nxs       # issue #15
```

### FASE 5: Version y release

1. Actualizar version en `releases/` de `0.0.1` a `0.0.2`
2. Reconstruir binarios con `cargo build --release`
3. Generar paquetes de release

---

## 4. Archivos que requieren cambios (lista completa)

### Docs (14 archivos)
- `docs/README.md`
- `docs/language/variables/declaration.md`
- `docs/language/variables/input-output.md`
- `docs/language/operators/operadores.md`
- `docs/language/control-flow/loops.md`
- `docs/standard-library/collections/vector.md`
- `docs/standard-library/collections/stack.md`
- `docs/standard-library/collections/queue.md`
- `docs/standard-library/collections/map.md`
- `docs/language/data-types/data-struture.md`
- `docs/language/poo/structs.md`
- `docs/language/poo/classes.md`
- `docs/language/errors/try_catch.md`
- `docs/language/functions/return-values.md`

### Codigo fuente (4 archivos)
- `compiler/crates/nexis_parser/src/lib.rs`
- `compiler/crates/nexis_codegen/src/lib.rs`
- `interpreter/nexis_vm/src/evaluator.rs`
- `interpreter/nexis_vm/src/vm.rs`

### Pruebas (4 archivos nuevos)
- `tests/regression/01_semecolon_validation.nxs`
- `tests/regression/02_variable_type_preservation.nxs`
- `tests/regression/03_struct_construction.nxs`
- `tests/regression/04_struct_field_access.nxs`

---

## 5. Comandos para verificar

```bash
# Compilar el compilador
cd /home/bluenova/Escritorio/nexis-lang/compiler && cargo build --release

# Compilar el interprete
cd /home/bluenova/Escritorio/nexis-lang/interpreter && cargo build --release

# Ejecutar pruebas de paridad
cd /home/bluenova/Escritorio/nexis-lang/interpreter && bash scripts/run_interpreter_tests.sh --release

# Verificar que los 3 bugs abiertos se corrigieron
./compiler/target/release/nexisc tests/regression/01_semecolon_validation.nxs
./compiler/target/release/nexisc tests/regression/02_variable_type_preservation.nxs
./interpreter/target/release/nexisi tests/regression/03_struct_construction.nxs
```

---

## 6. Resumen ejecutivo

| Categoria | Encontrados | Corregidos en v0.0.2 | Pendientes |
|-----------|-------------|----------------------|------------|
| Errores en prueba.md | 5 issues | 2 (#02, #03) | 3 (#04, #10, #15) |
| Inconsistencias en docs | 21 | 0 | 21 |
| Enlaces rotos | 4 | 0 | 4 |
| Errores de codigo fuente | 4 bugs | 0 | 4 |

**La prioridad absoluta es FASE 1** — decidir las convenciones del lenguaje. Sin eso, cualquier correccion de docs puede crear nuevas contradicciones.
