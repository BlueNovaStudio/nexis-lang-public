# NEXIS: pendientes y propuestas

Documento de seguimiento para el compilador, el intérprete y las bibliotecas de NEXIS. Cada punto debe validarse contra la documentación y acompañarse de una prueba antes de considerarse terminado.

## Criterios de trabajo

- Confirmar primero el comportamiento actual con un caso mínimo reproducible.
- Verificar si la regla ya está definida en la documentación del lenguaje.
- Añadir o actualizar pruebas para evitar regresiones en el compilador y el intérprete.
- Documentar los cambios de sintaxis y sus mensajes de error.

## Incidencias

### 02. Variables sin inicializar

El compilador `nexisc` no parece informar de forma consistente cuando se utiliza una variable sin inicializar.

**Pendientes:**

- Definir cuándo una variable se considera inicializada.
- Emitir un error claro durante la compilación cuando se lea antes de asignarle un valor.
- Comprobar que la regla no afecte a otros operandos ni a variables inicializadas mediante una expresión válida.
- Contrastar el comportamiento con la documentación existente.

### 03. Carácter inesperado en `Console.print()`

Al compilar y ejecutar una llamada a `Console.print()`, aparece un carácter `%` al final de la línea.

**Pendientes:**

- Crear un caso mínimo que reproduzca el problema.
- Determinar si el carácter se genera en el compilador, el intérprete o la rutina de salida.
- Corregir el formato de salida y añadir una prueba que compruebe que no aparece texto adicional.

### 04. Validación del punto y coma

El punto y coma final de una declaración no parece validarse. Una declaración sin inicialización debería exigir `;` al final de la línea.

**Pendientes:**

- Definir si `;` es obligatorio en todas las declaraciones o solo en algunas construcciones.
- Emitir un error de sintaxis cuando falte el terminador requerido.
- Verificar que la regla no rompa declaraciones con inicialización ni otras instrucciones válidas.

## Funcionalidades propuestas

### 05. Importación obligatoria de estructuras de datos

Las estructuras de datos, como vectores, arrays y listas, no deberían estar disponibles automáticamente. Para utilizarlas, el programa debe inyectar explícitamente la biblioteca que las implementa.

Si se intenta crear una estructura sin importar su biblioteca mediante `inject`, el compilador debe indicar que el tipo o la estructura no está disponible.

**Pendientes:**

- Enumerar las estructuras que requieren biblioteca.
- Definir el mensaje de error para una estructura no importada.
- Probar que la importación habilita únicamente los símbolos esperados.

### 06. Importación selectiva con `inject`

Ampliar la sintaxis de inyección para importar una función o método concreto sin cargar toda la biblioteca.

Ejemplo propuesto:

```nexis
from math inject pow
```

La sintaxis y el comportamiento todavía no están respaldados por la documentación actual.

**Pendientes:**

- Confirmar si `from ... inject ...` encaja con la gramática de NEXIS.
- Definir el comportamiento cuando el símbolo no existe.
- Resolver conflictos entre símbolos con el mismo nombre.
- Documentar si también se permitirá importar clases, constantes o varios símbolos.

### 07. Bibliotecas y manejo de errores

Mejorar las bibliotecas existentes del compilador y del intérprete, incluyendo más casos de error y una gestión explícita de ambigüedades.

**Pendientes:**

- Inventariar las bibliotecas actuales y sus funciones públicas.
- Unificar los tipos y mensajes de error.
- Añadir casos límite y pruebas de entradas inválidas.
- Documentar las incompatibilidades o cambios de comportamiento.

### 08. Inicializadores para clases

Evaluar la incorporación de inicializadores para clases y subclases, equivalentes conceptualmente a `__init__` en Python o a los constructores en Java.

El objetivo es permitir que una instancia configure su estado al crearse y facilitar la programación orientada a objetos.

**Pendientes:**

- Decidir si NEXIS utilizará constructores, un método especial o ambas opciones.
- Definir la sintaxis, los parámetros y la llamada a inicializadores de la clase base.
- Especificar reglas de visibilidad, sobrecarga y herencia.
- Actualizar la documentación y añadir ejemplos antes de implementarlo.

## Herramientas de compilación y ejecución

### 09. Nombres y flujo de ejecución

Revisar los nombres del compilador y del intérprete para que sean más claros, y definir una interfaz de comandos consistente.

El flujo debería ser similar al de herramientas conocidas, por ejemplo:

```text
<compilador> main.nxs -o main
./main
```

**Pendientes:**

- Elegir nombres consistentes para el compilador y el intérprete.
- Definir comandos para compilar, ejecutar y mostrar ayuda o versión.
- Permitir indicar el archivo de salida con una opción como `-o`.
- Generar el ejecutable o artefacto correspondiente en la ubicación solicitada.
- Documentar las diferencias entre Linux, Windows y otros sistemas operativos.
- Definir cómo se comunicarán los errores, el código de salida y los archivos temporales.

## Estado

Los puntos de este documento son propuestas de trabajo. Antes de implementarlos, se debe registrar para cada uno un caso reproducible, el comportamiento esperado y una prueba automatizada o manual verificable.

## Nuevas observaciones de validación

### 10. `add()` dentro de bucles y condicionales

La función `add()` no agrega correctamente elementos a las estructuras cuando se usa dentro de un bucle y luego dentro de una condición `if`.

Ejemplo reportado:

```nxs
Vector<int> notas = {}

int nota;
int promedio = 0;

for i in 1..10 {
    nota = Console.input(text=fs"Ingresa la nota {i}: ")

    if (nota <= 20 && nota >= 0):
        notas.add(nota)
}

Console.println(notas)
```

**Pendientes:**

- Revisar el flujo interno de `Vector.add()`.
- Confirmar si el problema se debe a la validación del valor, a la condición o a una mala actualización del estado del vector.
- Probar varios escenarios con datos válidos e inválidos al mismo tiempo.
- Añadir una prueba de regresión para `add()` dentro de loops.

### 11. Declaración de estructuras con tipo explícito

También debe permitirse declarar estructuras con una sintaxis explícita como:

```nxs
Vector<int> num;
```

y debe seguir exactamente las mismas reglas de declaración que cualquier otra variable.

**Pendientes:**

- Confirmar si la gramática acepta ambos formatos: inicializado y no inicializado.
- Definir si el punto y coma final es obligatorio o si es opcional solo en ciertos contextos.
- Documentar la diferencia entre declarar sin inicializar y declarar con valor inicial.

### 12. Tipado fuerte en estructuras de datos

Las estructuras de datos con tipo determinado, como `Vector<int>`, deberían aceptar solo datos del tipo correcto.

Si se intenta agregar un `string`, `float` o un tipo diferente a un vector de enteros, debe producir un error claro.

**Pendientes:**

- Definir qué ocurre cuando el valor no coincide con el tipo declarado.
- Añadir mensajes de error específicos, por ejemplo: "tipo incompatible en Vector<int>".
- Verificar que la validación se aplique también a inserciones, reemplazos y asignaciones.

### 13. Soporte para colecciones con elementos mixtos

El lenguaje necesita soporte para estructuras heterogéneas, al menos con una opción explícita para permitir elementos mixtos dentro de la misma colección.

Ejemplos posibles:

- `auto` para inferencia de tipos.
- Un tipo especial que permita múltiples tipos de elementos.
- Una estructura generica o dinámica que acepte `int`, `string`, `float` y `double` mezclados.

**Pendientes:**

- Decidir si la mezcla de tipos será opcional o por defecto.
- Definir la sintaxis formal.
- Documentar el comportamiento y el costo de la operación.
- Evaluar si esto afecta la seguridad del tipo o la generación de código.

### 14. Función `type()`

Falta soporte para una función general que permita consultar el tipo de una variable o estructura.

Ejemplo esperado:

```nxs
Console.print(type(34))
// -> int

Vector<int> num = {}
Console.print(type(num))
// -> Vector<int>
```

**Pendientes:**

- Definir el formato de retorno de `type()`.
- Decidir si devuelve un nombre textual, un identificador interno o un token equivalente.
- Añadir soporte para tipos básicos, estructuras, objetos y clases.
- Documentar la diferencia entre el tipo declarativo y el valor actual.

### 15. Soporte de `struct` no funcional

El soporte para `struct` aún no funciona como se indica en la documentación.

Ejemplo reportado:

```nxs
struct Contacto {
    string nombre
    string telefono
    string categoria
}

Contacto persona = Contacto()
persona.nombre = "Ana"
persona.telefono = "123456789"
persona.categoria = "trabajo"

Console.print(persona.nombre)   // Ana
```

**Pendientes:**

- Verificar si la gramática de `struct` permite instanciación con paréntesis y luego acceso a campos.
- Revisar la semántica de la asignación de propiedades.
- Confirmar si el problema se debe a la definición del tipo, el constructor o la lectura del campo.
- Añadir pruebas para `struct` con inicialización, acceso y modificación.

### 16. Impresión de estructuras versus variables

Se propone una diferencia clara entre imprimir una variable simple y una estructura de datos.

El enfoque actual de `Console.print()` para listas o colecciones es simple, pero el usuario considera que la impresión directa de estructuras no es la mejor práctica para aprender la lógica del programa.

**Propuesta:**

- Mantener `Console.print()` para valores escalares.
- Reforzar el uso de bucles para iterar sobre estructuras y mostrar sus elementos.
- Definir un formato más explícito para la salida de colecciones, por ejemplo `Console.println(notas)` o una representación detallada por índice.

**Pendientes:**

- Decidir si la salida de una estructura debe ser textual, por lista o por elementos.
- Documentar el comportamiento esperado y qué se recomienda para la depuración.
- Mantener compatibilidad con el estilo simple de Python sin perder legibilidad.

## Priorización recomendada

1. Corregir errores de validación y tipado (`add()`, `Vector<int>`, semántica del `;`).
2. Solucionar `struct` y acceso a propiedades.
3. Mejorar la documentación de importación y bibliotecas.
4. Añadir `type()` para introspección.
5. Definir soporte para colecciones heterogéneas y constructs de inicialización.
6. Revisar nombres del compilador, flujo de ejecución y artefactos compilados.

## Conclusión

Este documento ya sirve como base de seguimiento del lenguaje NEXIS. La mejora principal que falta es convertir todas estas observaciones en pruebas reproducibles y en reglas formales de la documentación, para que cada corrección quede respaldada por evidencia y no por experiencia subjetiva.

### 17. Estandarización de documentación y mensajes del lenguaje

Muchas de las funciones y estructuras de datos están documentadas en español, pero el lenguaje debe seguir un estándar internacional y consistente en inglés. Esto incluye nombres de funciones, bibliotecas, errores, mensajes del compilador, importaciones y cualquier texto visible para el usuario.

**Objetivo principal:**

- Obtener una versión de documentación `v0.0.2` más clara, consistente y técnicamente sólida.
- Corregir incoherencias entre funciones, estructuras, sintaxis y ejemplos de uso.
- Alinear el compilador, el intérprete y la documentación con una misma convención de nomenclatura.

**Requisitos propuestos:**

- Revisar toda la documentación de estructuras de datos y convertir nombres, ejemplos y explicaciones a inglés.
- Buscar inconsistencias entre diferentes módulos, librerías y casos de uso.
- Unificar el lenguaje de errores para que el compilador e intérprete emitan mensajes en inglés.
- Mantener la documentación en español solo como apoyo contextual, pero el producto final debe seguir un estándar internacional y general.
- Definir una convención clara para:
  - funciones
  - clases
  - métodos
  - librerías
  - palabras reservadas
  - mensajes de error
  - importaciones
  - ejemplos de uso

**Criterios de aceptación:**

- Todos los nombres visibles del lenguaje deben estar en inglés.
- Los errores generados por el compilador y el intérprete deben mostrarse en inglés.
- La documentación debe reflejar exactamente la sintaxis real implementada.
- Las funciones y estructuras deben estar descritas con la misma nomenclatura en todos los ejemplos.
- La documentación `v0.0.2` debe cubrir los puntos reportados en este documento y dejar claro el comportamiento esperado del compilador e intérprete.

**Prioridad recomendada:**

1. Revisar y corregir la documentación actual.
2. Unificar nombres, errores y convenciones de estilo.
3. Resolver inconsistencias funcionales reportadas en los puntos anteriores.
4. Preparar la versión `v0.0.2` con ejemplos, reglas y mensajes estandarizados.

**Conclusión:**

La documentación no solo debe ser clara, sino también coherente con la implementación real del lenguaje. El producto final debe ser estándar, profesional y comprensible para cualquier usuario sin depender del idioma original del creador del lenguaje.