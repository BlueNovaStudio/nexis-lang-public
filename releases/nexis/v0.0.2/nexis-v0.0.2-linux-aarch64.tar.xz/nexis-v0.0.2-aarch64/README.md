# nexis-lang

Lenguaje de programación **Nexis** y su ecosistema de herramientas.

## Estructura del proyecto

| Carpeta | Descripción |
|---|---|
| `docs/` | Documentación oficial del lenguaje |
| `tests/` | Tests y casos de uso del lenguaje |
| `extension/` | Extensión de VS Code (sintaxis, comentarios, snippets y consola) |
| `compiler/` | Compilador del lenguaje |
| `interpreter/` | Intérprete del lenguaje |
| `installer/` | Pipeline de releases (compila artefactos y fabrica instaladores `.deb`, `.tar.xz`, `.exe` NSIS, `.pkg`) |
| `releases/` | Historial de versiones de cada componente y del producto completo |

## Releases

- **v0.0.1** de los componentes **docs**, **compiler** e **interpreter** publicadas, además del **producto completo** con instaladores tipo app en `releases/nexis/v0.0.1/`.
- **v0.0.2** de la **extensión** publicada: gramática realineada al 100 % con la documentación (keywords, tipos, operadores, `fs"…"`, `#inject`…), snippets, icono y manual interno.
- Índice completo en [releases/README.md](releases/README.md).
- Falta por publicar la versión completa **Nexis V1.0.0**.

Scripts de fabricación:

- `installer/scripts/release-all.sh` → **un solo comando** para publicar: compila, empaqueta .zip e instaladores (`--all`, `--linux`, `--windows`, `--mac`, `--arch`, `--dry-run`).
- `compiler/scripts/release.sh` → releases del compilador (`nexisc`), delega en `installer/scripts/build.sh`.
- `interpreter/scripts/release.sh` → releases del intérprete (`nexisi`), delega en `installer/scripts/build.sh`.
- `installer/scripts/build.sh` → **compila** `nexisc`/`nexisi` (x86_64 y aarch64, sin el SO en el nombre) y empaqueta los `.zip` por separado.
- `installer/scripts/package.sh` → **organiza** docs/tests/extensión y **fabrica** los instaladores tipo app (`.deb`/`.tar.xz` en Linux, `.exe` en Windows, `.pkg` en macOS) con README desde plantillas y `COMPATIBILIDAD.md`.
- `installer/config.sh` → tablas de configuración por componente (versión, tipo, carpeta, arquitecturas). **Es lo único que hay que editar para publicar.**

> Los artefactos siguen la convención `<proyecto>-<versión>-<arquitectura>.<ext>` (sin `linux`/`windows`/`mac`).

## Documentación técnica

- [**Compilador** (`compiler/README.md`)](compiler/README.md): pipeline lexer → parser → sema → codegen, el AST y sus fases.
- [**Intérprete** (`interpreter/README.md`)](interpreter/README.md): la VM `nexisi` (tree-walk y bytecode), su runtime y el REPL.

> Ambos comparten el mismo frontend (lexer/parser/sema) y los mismos tipos, por lo que producen exactamente las mismas salidas y errores. La suite `interpreter/scripts/run_interpreter_tests.sh` lo verifica.