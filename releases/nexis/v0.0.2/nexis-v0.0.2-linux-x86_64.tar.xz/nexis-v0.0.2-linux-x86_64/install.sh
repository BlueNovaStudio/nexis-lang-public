#!/usr/bin/env bash
# =============================================================================
# install.sh — Instalador Linux genérico de Nexis (demo v0.0.2)
# =============================================================================
# Copia los binarios `nexisc`/`nexisi` y la documentación a un directorio de
# instalación, y añade ese directorio al PATH si está en un shell Bash.
#
# Uso:
#   ./install.sh                    # instala en ~/.local (recomendado)
#   sudo ./install.sh /usr/local    # instalación global (todos los usuarios)
#   INSTALL_DIR=/opt/nexis ./install.sh
# =============================================================================

set -euo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"

# 1. Directorio de instalación (por defecto ~/.local, o /usr/local si es root)
if [ -n "${INSTALL_DIR:-}" ]; then
    PREFIX="$INSTALL_DIR"
elif [ -n "${1:-}" ]; then
    PREFIX="$1"
elif [ "$(id -u)" = "0" ]; then
    PREFIX="/usr/local"
else
    PREFIX="$HOME/.local"
fi

BIN_DIR="$PREFIX/bin"
DOC_DIR="$PREFIX/share/doc/nexis"

echo "==> Instalando Nexis demo v0.0.2 en: $PREFIX"

# 2. Copiar binarios
mkdir -p "$BIN_DIR"
install -m 0755 "$SOURCE_DIR/bin/nexisc" "$BIN_DIR/"
install -m 0755 "$SOURCE_DIR/bin/nexisi" "$BIN_DIR/"

# 3. Copiar documentación y compatibilidad
mkdir -p "$DOC_DIR"
cp -r "$SOURCE_DIR/docs/." "$DOC_DIR/" 2>/dev/null || true
cp "$SOURCE_DIR/COMPATIBILIDAD.md" "$DOC_DIR/" 2>/dev/null || true

# 4. Añadir al PATH (solo si no está, y solo si el shell es Bash)
if [ -n "${BASH_VERSION:-}" ] && [[ ":$PATH:" != *":$BIN_DIR:"* ]]; then
    SHELL_RC="${HOME}/.bashrc"
    if [ -f "${HOME}/.zshrc" ]; then SHELL_RC="${HOME}/.zshrc"; fi
    # Solo añade si el directorio aún no fue declarado en el archivo
    if ! grep -qs "export PATH=\"$BIN_DIR" "$SHELL_RC"; then
        echo "export PATH=\"$BIN_DIR:\$PATH\"" >> "$SHELL_RC"
        echo "   -> añadido $BIN_DIR al PATH en $SHELL_RC"
    fi
    echo "==> Recarga tu shell: source ~/.bashrc (o ~/.zshrc)"
fi

echo "==> Listo. Prueba con: nexisi --version"
echo "==> Para desinstalar: $SOURCE_DIR/uninstall.sh $PREFIX"