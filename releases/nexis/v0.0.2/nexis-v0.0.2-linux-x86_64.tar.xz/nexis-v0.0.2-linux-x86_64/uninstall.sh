#!/usr/bin/env bash
# =============================================================================
# uninstall.sh — Desinstalador de Nexis (demo v0.0.2)
#
# Uso:
#   ./uninstall.sh                    # desinstala de ~/.local
#   sudo ./uninstall.sh /usr/local    # desinstala de una instalación global
#   INSTALL_DIR=/opt/nexis ./uninstall.sh
# =============================================================================

set -euo pipefail

if [ -n "${INSTALL_DIR:-}" ]; then
    PREFIX="$INSTALL_DIR"
elif [ -n "${1:-}" ]; then
    PREFIX="$1"
elif [ "$(id -u)" = "0" ]; then
    PREFIX="/usr/local"
else
    PREFIX="$HOME/.local"
fi

BIN_DIR="$PREFIX/bin"
DOC_DIR="$PREFIX/share/doc/nexis"

echo "==> Desinstalando Nexis v0.0.2 de: $PREFIX"

rm -f "$BIN_DIR/nexisc" "$BIN_DIR/nexisi"
rm -rf "$DOC_DIR"

# Limpia la línea del PATH añadida por install.sh
for rc in "${HOME}/.bashrc" "${HOME}/.zshrc"; do
    [ -f "$rc" ] && sed -i "\|export PATH=\"$BIN_DIR|d" "$rc" 2>/dev/null || true
done

echo "==> Nexis desinstalado."