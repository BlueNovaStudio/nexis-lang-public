# Pila (Stack) en Nexis

Una `Stack<T>` almacena elementos con la regla LIFO: el último elemento que entra es el primero que sale.

## 1. Importación

```
#inject stack;
```

## 2. Declaración

```
Stack<string> historial = Stack()
```

## 3. Métodos

### `apilar(valor)`
Agrega un elemento en la parte superior.

```
historial.push("pantalla_inicio")
historial.push("pantalla_ajustes")
```

### `desapilar()`
Elimina y devuelve el elemento superior.

```
string pantalla = historial.pop()
```

### `cima()`
Devuelve el elemento superior sin eliminarlo.

```
string actual = historial.cima()
```

### `esta_vacia()` y `longitud()`
Consultan si la pila está vacía y cuántos elementos contiene.

```
bool vacia = historial.isEmpty()
int total = historial.length()
```

## 4. Ejemplo completo

```
#inject stack;

Stack<string> historial = Stack()
historial.push("inicio")
historial.push("ajustes")

while (!historial.isEmpty()) {
	Console.print(historial.pop())
}
```

## 5. Complejidad

| Método | Complejidad |
|--------|-------------|
| `apilar(valor)` | O(1) |
| `desapilar()` | O(1) |
| `cima()` | O(1) |
| `esta_vacia()` | O(1) |
| `longitud()` | O(1) |

## 6. Error común

No se puede declarar una pila sin indicar el tipo de sus elementos:

```
Stack historial = Stack()   // error
```

Usa `Stack<T>` y asegúrate de importar `stack`.
