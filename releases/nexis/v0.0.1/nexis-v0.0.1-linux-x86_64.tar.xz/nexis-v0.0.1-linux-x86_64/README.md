# nexis-lang

Lenguaje de programación **Nexis** y su ecosistema de herramientas.

## Estructura del proyecto

| Carpeta | Descripción |
|---|---|
| `docs/` | Documentación oficial del lenguaje |
| `tests/` | Tests y casos de uso del lenguaje |
| `extension/` | Extensión de VS Code (sintaxis, comentarios y consola) |
| `compiler/` | Compilador del lenguaje |
| `interpreter/` | Intérprete del lenguaje |
| `installer/` | Instaladores tipo app (`.deb`, `.tar.xz`, `.exe` NSIS, `.pkg`) |
| `releases/` | Historial de versiones de cada componente y del producto completo |

## Releases

- **v0.0.1** de los componentes **docs**, **extension**, **compiler** e **interpreter** publicadas (ver [índice de releases](releases/README.md)), además del **producto completo** con instaladores tipo app en `releases/nexis/v0.0.1/`.
- Falta por publicar la versión completa **Nexis V1.0.0**.

Scripts de fabricación:

- `compiler/scripts/release.sh` → releases del compilador (`nexisc`).
- `interpreter/scripts/release.sh` → releases del intérprete (`nexisi`).
- `installer/scripts/build_installer.sh` → instalador universal `.zip`.
- `installer/scripts/build_app_installers.sh` → **instaladores tipo app** (`.deb`/`.tar.xz` en Linux, `.exe` en Windows, `.pkg` en macOS) con `COMPATIBILIDAD.md` (versiones de docs/extensión y limitantes demo).

## Documentación técnica

- [**Compilador** (`compiler/README.md`)](compiler/README.md): pipeline lexer → parser → sema → codegen, el AST y sus fases.
- [**Intérprete** (`interpreter/README.md`)](interpreter/README.md): la VM `nexisi` (tree-walk y bytecode), su runtime y el REPL.

> Ambos comparten el mismo frontend (lexer/parser/sema) y los mismos tipos, por lo que producen exactamente las mismas salidas y errores. La suite `interpreter/scripts/run_interpreter_tests.sh` lo verifica.