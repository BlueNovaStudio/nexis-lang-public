# nexis-lang

Lenguaje de programación **Nexis** y su ecosistema de herramientas.

## Estructura del proyecto

| Carpeta | Descripción |
|---|---|
| `docs/` | Documentación oficial del lenguaje |
| `tests/` | Tests y casos de uso del lenguaje |
| `extension/` | Extensión de VS Code (sintaxis, comentarios, snippets y consola) |
| `compiler/` | Compilador del lenguaje |
| `interpreter/` | Intérprete del lenguaje |
| `installer/` | Instaladores tipo app (`.deb`, `.tar.xz`, `.exe` NSIS, `.pkg`) |
| `releases/` | Historial de versiones de cada componente y del producto completo |

## Releases

- **v0.0.1** de los componentes **docs**, **compiler** e **interpreter** publicadas, además del **producto completo** con instaladores tipo app en `releases/nexis/v0.0.1/`.
- **v0.0.2** de la **extensión** publicada: gramática realineada al 100 % con la documentación (keywords, tipos, operadores, `fs"…"`, `#inject`…), snippets, icono y manual interno.
- Índice completo en [releases/README.md](releases/README.md).
- Falta por publicar la versión completa **Nexis V1.0.0**.

Scripts de fabricación:

- `compiler/scripts/release.sh` → releases del compilador (`nexisc`).
- `interpreter/scripts/release.sh` → releases del intérprete (`nexisi`).
- `installer/scripts/build_app_installers.sh` → **instaladores tipo app** (`.deb`/`.tar.xz` en Linux, `.exe` en Windows, `.pkg` en macOS) con `COMPATIBILIDAD.md` (versiones de docs/extensión y limitantes demo).

## Documentación técnica

- [**Compilador** (`compiler/README.md`)](compiler/README.md): pipeline lexer → parser → sema → codegen, el AST y sus fases.
- [**Intérprete** (`interpreter/README.md`)](interpreter/README.md): la VM `nexisi` (tree-walk y bytecode), su runtime y el REPL.

> Ambos comparten el mismo frontend (lexer/parser/sema) y los mismos tipos, por lo que producen exactamente las mismas salidas y errores. La suite `interpreter/scripts/run_interpreter_tests.sh` lo verifica.