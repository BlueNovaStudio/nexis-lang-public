# nexis-lang

Lenguaje de programación **Nexis** y su ecosistema de herramientas.

## Estructura del proyecto

| Carpeta | Descripción |
|---|---|
| `docs/` | Documentación oficial del lenguaje |
| `tests/` | Tests y casos de uso del lenguaje |
| `extension/` | Extensión de VS Code (sintaxis, comentarios y consola) |
| `compiler/` | Compilador del lenguaje |
| `interpreter/` | Intérprete del lenguaje |
| `installer/` | Instalador |
| `releases/` | Historial de versiones de cada componente y del producto completo |

## Releases

- **v0.0.1** de los componentes **docs**, **extension** y **compiler** publicadas (ver [índice de releases](releases/README.md)), además de un **instalador del producto completo** (`releases/nexis/v0.0.1/`).
- Faltan por publicar el **intérprete** como componente independiente y la versión completa **Nexis V1.0.0**.

## Documentación técnica

- [**Compilador** (`compiler/README.md`)](compiler/README.md): pipeline lexer → parser → sema → codegen, el AST y sus fases.
- [**Intérprete** (`interpreter/README.md`)](interpreter/README.md): la VM `nexisi` (tree-walk y bytecode), su runtime y el REPL.

> Ambos comparten el mismo frontend (lexer/parser/sema) y los mismos tipos, por lo que producen exactamente las mismas salidas y errores. La suite `interpreter/scripts/run_interpreter_tests.sh` lo verifica.