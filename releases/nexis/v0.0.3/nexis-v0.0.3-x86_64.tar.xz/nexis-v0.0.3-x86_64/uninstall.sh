#!/usr/bin/env bash
# =============================================================================
# uninstall.sh — Desinstalador de Nexis (demo vv0.0.3)
#
# Uso:
#   ./uninstall.sh                    # desinstala de ~/.local
#   sudo ./uninstall.sh /usr/local    # desinstala de una instalación global
#   INSTALL_DIR=/opt/nexis ./uninstall.sh
# =============================================================================

set -euo pipefail

if [ -n "${INSTALL_DIR:-}" ]; then
    PREFIX="$INSTALL_DIR"
elif [ -n "${1:-}" ]; then
    PREFIX="$1"
elif [ "$(id -u)" = "0" ]; then
    PREFIX="/usr/local"
else
    PREFIX="$HOME/.local"
fi

BIN_DIR="$PREFIX/bin"
DOC_DIR="$PREFIX/share/doc/nexis"
COMPONENTS="${NEXIS_COMPONENTS:-all}"
[ -f "$PREFIX/.nexis-components" ] && COMPONENTS="$(cat "$PREFIX/.nexis-components")"

echo "==> Desinstalando Nexis vv0.0.3 de: $PREFIX"

case "$COMPONENTS" in
    all|compiler) rm -f "$BIN_DIR/nexisc" ;;
esac
case "$COMPONENTS" in
    all|interpreter) rm -f "$BIN_DIR/nexisi" ;;
esac
rm -rf "$DOC_DIR"
rm -f "$PREFIX/.nexis-components"

# Limpia solo las líneas que añadió install.sh.
for rc in "${HOME}/.bashrc" "${HOME}/.zshrc"; do
    [ -f "$rc" ] && sed -i "/# Nexis vv0.0.3/,+1d" "$rc" 2>/dev/null || true
done
[ -f "${HOME}/.profile" ] && sed -i "/# Nexis vv0.0.3/,+1d" "${HOME}/.profile" 2>/dev/null || true

echo "==> Nexis desinstalado."