def mayor_edad(edad):
    if(edad >= 18):
        return True
    else:
        return False

mayor = mayor_edad(20)
print(mayor)