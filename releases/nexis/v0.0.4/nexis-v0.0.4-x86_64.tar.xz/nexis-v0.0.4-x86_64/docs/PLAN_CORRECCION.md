# Correcciones del plan — Nexis v0.0.3

Análisis completo de errores en `prueba.md`, anomalias en la documentacion, y contradicciones entre el compilador/interprete y lo documentado.

---

## 1. Estado actual de los errores reportados en `prueba.md`

| # | Incidencia | Estado implementado | Veredicto |
|---|------------|--------------------------------|-----------|
| 02 | Variable sin inicializar | **CORREGIDO** — `nexisc`/`nexisi` emiten `error[NX00]: Uninitialized variable` de forma consistente | OK |
| 03 | Caracter `%` en `Console.print()` | **CORREGIDO** — salida limpia, sin caracteres extra | OK |
| 04 | Validación del punto y coma | **CORREGIDO** — `;` en declaraciones sin inicializador y `#inject`; no se usa en declaraciones inicializadas ni asignaciones | OK |
| 10 | `add()` en bucles + condicionales | **CORREGIDO** — se conserva el tipo declarado y `Console.input` se convierte al asignarlo | OK |
| 11 | Declaración de estructuras con tipo explícito | **CORREGIDO** — las declaraciones tipadas siguen la regla condicional de `;` | OK |
| 15 | `struct` y clases básicas | **CORREGIDO** — constructores vacíos, acceso/asignación de campos y métodos de clase | OK |

### Raiz del error #10 (importante)

Con `int nota;`, ambos runtimes conservan el tipo declarado mientras la variable espera su primera asignación. Al asignarle `Console.input(...)`, el texto se convierte al tipo declarado, así que `nota <= 20` y `notas.add(nota)` trabajan con enteros.

---

## 2. Inconsistencias encontradas en la documentacion (21 errores)

### A. Enlaces rotos o intercambiados

| Archivo | Linea | Error | Correccion |
|---------|-------|-------|------------|
| `docs/README.md` | 31 | Dice "Funciones con retorno" pero enlaza a `funtions.md` (que es "sin retorno") | Intercambiar labels ✅|
| `docs/README.md` | 32 | Dice "Funciones sin retorno" pero enlaza a `return-values.md` (que es "con retorno") | Intercambiar labels ✅|
| `docs/language/variables/input-output.md` | 11 | Ruta `../operadores/operadores.md` no existe | Cambiar a `../operators/operadores.md` ✅|
| `docs/language/operators/operadores.md` | 7 | Ruta `../README.md` apunta a `docs/language/README.md` (no existe) | Cambiar a `../../README.md` ✅|

### B. Reglas contradictorias

| Archivo | Linea | Error | Correccion |
|---------|-------|-------|------------|
| `docs/language/variables/declaration.md` | 10, 15 | Dice que declaracion lleva `;` pero TODOS los ejemplos del archivo y del resto de docs omiten el `;` | Decidir: `;` obligatorio o no, y actualizar TODO consistentemente ✅|
| `docs/language/functions/return-values.md` | 23-24 | Dice que `emit ->` es solo para bloques multi-linea | Coherente internamente pero contradice `funtions.md` ✅ |
| `docs/language/operators/operadores.md` | 186-187 | Operador ternario `=> ... <-->` listado DESPUES de asignacion (precedencia 10), pero se usa como expresion que asigna | Mover ternario ANTES de asignacion (precedencia ~3-4) ✅|

### C. Caos de nombres Espanol/Ingles en metodos de colecciones

**El lenguaje NO define cual es el nombre real.** Los docs dicen una cosa en headers y otra en codigo:

| Estructura | Header (espanol) | Codigo (ingles) | `data-struture.md` | Metodo real en codigo fuente |
|------------|-------------------|------------------|--------------------|-----------------------------|
| Vector | `agregar` | `add` | `add` | `add` |
| Vector | `obtener` | `get` | `get` | `get` |
| Vector | `eliminar` | `remove` | `remove` | `remove` |
| Vector | `ordenar` | `sort` | `sort` | `sort` |
| Vector | `longitud` | `length` | — | `length` |
| Vector | `esta_vacio` | `isEmpty` | — | `isEmpty` |
| Stack | `apilar` | `push` | `push` | `push` |
| Stack | `desapilar` | `pop` | `pop` | `pop` |
| Stack | `cima` | `cima` | `peek` | `peek` |
| Queue | `encolar` | `enqueue` | `enqueue` | `enqueue` |
| Queue | `desencolar` | `dequeue` | `dequeue` | `dequeue` |
| Queue | `frente` | — | `front` | `front` |
| Map | `poner` | `put` | `put` | `put` |
| Map | `obtener` | `get` | `get` | `get` |
| Map | `contiene` | `contains` | `contains` | `contains` |

**Accion:** Usar nombres ingleses (que son los que el codigo implementa) en headers, codigo y tablas.

### D. Otros errores

| Archivo | Linea | Error | Correccion |
|---------|-------|-------|------------|
| `docs/language/control-flow/loops.md` | 1 | Resto de prompt de IA: "Entendido. Aqui tienes la version revisada..." | Eliminar esa linea |
| `docs/language/poo/structs.md` | 17, 22 | Dice "no se asignan valores en la definicion" pero luego llama `Contacto()` sin argumentos | Documentar constructor correcto o cambiar ejemplo |
| `docs/language/poo/classes.md` | 13, 25 | Template muestra `-> retorno` para todos los metodos, pero ejemplo usa `void` | Actualizar template para incluir `void` |
| `docs/language/errors/try_catch.md` | 150 | Usa `vector traza` (sin tipo) pero todas las colecciones deben ser tipadas `Vector<T>` | Cambiar a `Vector<string> traza` |
| `docs/language/data-types/data-struture.md` | 15 | Usa nombres ingleses para Map (`put`, `get`) pero `map.md` documenta en espanol | Unificar |

---

## 3. Plan de accion para corregir TODO (priorizado)

### FASE 1: Convenciones del lenguaje (decididas)

Las convenciones ya están implementadas en parser, analizador semántico y runtimes:

1. **Punto y coma:** `;` es obligatorio solo en declaraciones sin inicializar, en todas, o en ninguna?
   - `int a;` y `Vector<int> nums;` requieren `;` si la declaración no tiene inicializador.
   - `int a = 2` y las asignaciones (`a = 2`) no llevan `;`.
   - `#inject Vector;` requiere `;`.
   - **Decisión implementada:** `;` es obligatorio para declaraciones/campos sin inicializador y directivas `#inject`; no se usa en declaraciones inicializadas ni asignaciones

2. **Nombres de metodos:** Espanol o Ingles?
   - Los métodos canónicos usan inglés (`add`, `get`, `remove`, `push`, `pop`, etc.).
   - **Decisión implementada:** encabezados y ejemplos usan nombres ingleses; los alias españoles siguen disponibles por compatibilidad

3. **Struct:** Como se instancia?
   - Se admiten constructores de estructuras con valores y acceso `.` a sus campos.
   - Las clases básicas permiten constructor vacío, campos, asignación de campos y métodos.

### FASE 2: Documentación corregida

| Prioridad | Archivo | Cambios |
|-----------|---------|---------|
| 1 | `docs/README.md` | Intercambiar labels lineas 31-32 |
| 2 | `docs/language/variables/declaration.md` | Unificar regla de `;` (decidir en FASE 1), alinear ejemplos |
| 3 | `docs/language/variables/input-output.md` | Corregir ruta linea 11: `../operators/operadores.md` |
| 4 | `docs/language/operators/operadores.md` | Corregir ruta linea 7, mover precedencia ternario |
| 5 | `docs/language/control-flow/loops.md` | Eliminar linea 1 (resto de IA) |
| 6 | `docs/standard-library/collections/vector.md` | Renombrar todos los headers a ingles |
| 7 | `docs/standard-library/collections/stack.md` | Renombrar headers y tabla a ingles |
| 8 | `docs/standard-library/collections/queue.md` | Renombrar headers y tabla a ingles |
| 9 | `docs/standard-library/collections/map.md` | Renombrar headers a ingles |
| 10 | `docs/language/data-types/data-struture.md` | Verificar consistencia con metodos reales |
| 11 | `docs/language/poo/structs.md` | Corregir ejemplo de instanciacion y acceso a campos |
| 12 | `docs/language/poo/classes.md` | Actualizar template para incluir `void` |
| 13 | `docs/language/errors/try_catch.md` | Cambiar `vector traza` a `Vector<string> traza` |
| 14 | `docs/language/functions/return-values.md` | Verificar que la regla de `emit` no contradiga otros docs |

### FASE 3: Cambios de código implementados

Parser, AST, análisis semántico, compilador, intérprete de árbol y VM ahora comparten las reglas de declaraciones y soportan estructuras y clases básicas con campos y métodos. El ejecutable `nexisi` también resuelve módulos locales de `#inject`.

### FASE 4: Regresiones agregadas y ejecutadas

Los casos de regresión están en `tests/regression/` y se ejecutaron con compilador e intérprete:

```
tests/
  regression/
    00_semicolon_rules.nxs           # issue #04
    01_variable_type_preservation.nxs # issue #10
    02_struct_construction.nxs       # issue #15
    03_struct_field_access.nxs       # issue #15
    04_class_methods.nxs
    05_class_init_self.nxs
```

### FASE 5: Version y release

El código fuente de este workspace corresponde a v0.0.3. La generación y publicación de paquetes de release queda como tarea de distribución independiente; este plan registra los cambios implementados y su validación local.

---

## 4. Archivos que requieren cambios (lista completa)

### Documentación revisada
- `docs/README.md`
- `docs/language/variables/declaration.md`
- `docs/language/variables/input-output.md`
- `docs/language/operators/operadores.md`
- `docs/language/control-flow/loops.md`
- `docs/standard-library/collections/vector.md`
- `docs/standard-library/collections/stack.md`
- `docs/standard-library/collections/queue.md`
- `docs/standard-library/collections/map.md`
- `docs/language/data-types/data-struture.md`
- `docs/language/poo/structs.md`
- `docs/language/poo/classes.md`
- `docs/language/errors/try_catch.md`
- `docs/language/functions/return-values.md`

### Código fuente
- Parser y AST del compilador, análisis semántico y generación de código.
- Intérprete `nexisi`, runtime del árbol y VM de bytecode.
- Manifiestos Cargo para enlazar los crates compartidos.

### Regresiones
- `tests/regression/00_semicolon_rules.nxs`
- `tests/regression/01_variable_type_preservation.nxs`
- `tests/regression/02_struct_construction.nxs`
- `tests/regression/03_struct_field_access.nxs`
- `tests/regression/04_class_methods.nxs`

---

## 5. Comandos para verificar

```bash
# Compilar el compilador
cd /home/bluenova/Escritorio/nexis-lang/compiler && cargo build --release

# Compilar el interprete
cd /home/bluenova/Escritorio/nexis-lang/interpreter && cargo build --release

# Verificar reglas de declaración
cargo run --manifest-path compiler/Cargo.toml --bin nexisc -- tests/regression/00_semicolon_rules.nxs

# Verificar métodos de clase en la VM
cargo run --manifest-path interpreter/Cargo.toml --bin nexisi -- --bytecode tests/regression/04_class_methods.nxs
```

---

## 6. Resumen ejecutivo

| Categoría | Encontrados | Corregidos en v0.0.3 | Pendientes |
|-----------|-------------|----------------------|------------|
| Errores reportados en `prueba.md` | 6 | 6 | 0 de los casos registrados |
| Inconsistencias documentales listadas | 21 | Revisadas/corregidas | 0 de las listadas |
| Funcionalidad POO | — | Clases con campos, métodos, `self` y constructor `init` | Sin herencia, modificadores de acceso ni genéricos definidos por usuario |

La versión actual ofrece POO básica y carga de bibliotecas Nexis locales. Las colecciones nativas se importan, por ejemplo, con `#inject Vector;`; las bibliotecas escritas por el usuario se cargan con una ruta local en `#inject`.
