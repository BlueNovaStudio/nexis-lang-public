# Cola (Queue) en Nexis

Una `Queue<T>` almacena elementos con la regla FIFO: el primer elemento que entra es el primero que sale.

## 1. Importación

```
#inject Queue;
```

## 2. Declaración

```
Queue<int> turnos_banco = Queue()
```

## 3. Métodos

### `enqueue(valor)`
Agrega un elemento al final de la cola.

### `dequeue()`
Elimina y devuelve el primer elemento.

### `front()`
Devuelve el primer elemento sin eliminarlo.

### `isEmpty()` y `length()`
Consultan el estado y el tamaño de la cola.

```
turnos_banco.enqueue(101)
turnos_banco.enqueue(102)
int turno = turnos_banco.dequeue()
```

## 4. Ejemplo completo

```
#inject Queue;

Queue<int> turnos_banco = Queue()
turnos_banco.enqueue(101)
turnos_banco.enqueue(102)

while (!turnos_banco.isEmpty()) {
	Console.print(turnos_banco.dequeue())
}
```

## 5. Complejidad

| Método | Complejidad |
|--------|-------------|
| `enqueue(valor)` | O(1) |
| `dequeue()` | O(1) |
| `front()` | O(1) |
| `isEmpty()` | O(1) |
| `length()` | O(1) |
