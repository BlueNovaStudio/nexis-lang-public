# Lista enlazada (Linked List) en Nexis

Una `LinkedList<T>` almacena elementos en nodos enlazados. Es útil cuando se insertan o eliminan elementos con frecuencia sin requerir memoria contigua.

## 1. Importación

```
#inject LinkedList;
```

## 2. Declaración

```
LinkedList<float> temperaturas = LinkedList()
```

La notación opcional `(1 -> 2 -> 3)` puede representar una lista enlazada literal cuando el lenguaje la habilite.

## 3. Métodos

### `agregar_frente(valor)`
Inserta un nodo al inicio.

### `agregar_fondo(valor)`
Inserta un nodo al final.

### `eliminar_frente()`
Elimina y devuelve el primer elemento.

### `obtener(indice)` y `longitud()`
Acceden a un elemento por índice y consultan el tamaño de la lista.

```
temperaturas.addFirst(36.5)
temperaturas.addLast(37.2)
float temperatura = temperaturas.get(0)
```

## 4. Ejemplo completo

```
#inject LinkedList;

LinkedList<float> temperaturas = LinkedList()
temperaturas.addFirst(36.5)
temperaturas.addLast(37.2)
temperaturas.removeFirst()
```

## 5. Complejidad

| Método | Complejidad |
|--------|-------------|
| `agregar_frente(valor)` | O(1) |
| `agregar_fondo(valor)` | O(1) |
| `eliminar_frente()` | O(1) |
| `obtener(indice)` | O(n) |
| `longitud()` | O(1) |
