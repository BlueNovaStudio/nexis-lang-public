# Pila (Stack) en Nexis

Una `Stack<T>` almacena elementos con la regla LIFO: el último elemento que entra es el primero que sale.

## 1. Importación

```
#inject Stack;
```

## 2. Declaración

```
Stack<string> historial = Stack()
```

## 3. Métodos

### `push(valor)`
Agrega un elemento en la parte superior.

```
historial.push("pantalla_inicio")
historial.push("pantalla_ajustes")
```

### `pop()`
Elimina y devuelve el elemento superior.

```
string pantalla = historial.pop()
```

### `peek()`
Devuelve el elemento superior sin eliminarlo.

```
string actual = historial.peek()
```

### `isEmpty()` y `length()`
Consultan si la pila está vacía y cuántos elementos contiene.

```
bool vacia = historial.isEmpty()
int total = historial.length()
```

## 4. Ejemplo completo

```
#inject Stack;

Stack<string> historial = Stack()
historial.push("inicio")
historial.push("ajustes")

while (!historial.isEmpty()) {
	Console.print(historial.pop())
}
```

## 5. Complejidad

| Método | Complejidad |
|--------|-------------|
| `push(valor)` | O(1) |
| `pop()` | O(1) |
| `peek()` | O(1) |
| `isEmpty()` | O(1) |
| `length()` | O(1) |

## 6. Error común

No se puede declarar una pila sin indicar el tipo de sus elementos:

```
Stack historial = Stack()   // error
```

Usa `Stack<T>` y asegúrate de importar `stack`.
