# Mapa (Map) en Nexis

Un `Map<K, V>` relaciona claves únicas con valores. Las claves tienen el tipo `K` y los valores el tipo `V`.

## 1. Importación

```
#inject Map;
```

## 2. Declaración

```
Map<string, int> inventario = {
	"manzanas": 50,
	"peras": 30
}
```

Las parejas clave-valor se separan con dos puntos (`:`). Las llaves sin dos puntos representan un conjunto.

## 3. Métodos

### `put(clave, valor)`
Agrega una pareja o reemplaza el valor de una clave existente.

### `get(clave)`
Devuelve el valor asociado a una clave.

### `contains(clave)`
Comprueba si una clave existe.

### `remove(clave)` y `length()`
Eliminan una pareja y consultan el número de parejas almacenadas.

```
inventario.put("naranjas", 20)
int cantidad = inventario.get("manzanas")
bool existe = inventario.contains("peras")
```

## 4. Ejemplo completo

```
#inject Map;

Map<string, string> capitales = {
	"Peru": "Lima",
	"Chile": "Santiago"
}
capitales.put("Argentina", "Buenos Aires")
```

## 5. Complejidad

| Método | Complejidad promedio |
|--------|----------------------|
| `put(clave, valor)` | O(1) |
| `get(clave)` | O(1) |
| `contains(clave)` | O(1) |
| `remove(clave)` | O(1) |
