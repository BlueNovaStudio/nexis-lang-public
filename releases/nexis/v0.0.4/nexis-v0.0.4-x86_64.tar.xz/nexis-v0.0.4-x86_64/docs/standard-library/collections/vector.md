# Vector en Nexis

## Introducción

`Vector<T>` es una estructura dinámica que almacena elementos del mismo tipo. Puede crecer o reducir su tamaño automáticamente.


## 1. Importación de la librería

Para usar vectores, importa la librería correspondiente:

```
#inject Vector;
```


## 2. Declaración

### Sintaxis

```
Vector<tipo> nombre;
```

### Ejemplo

```
Vector<int> nums = []
```

### Inicialización con valores

```
Vector<int> nums = [1, 2, 3, 4]
```

### Ejemplo completo

```
#inject Vector;

Vector<int> numeros = []
numeros = [10, 20, 30, 40]

// O en una sola línea
Vector<int> datos = [5, 10, 15, 20]
```


## 3. Métodos del vector

### `add(valor)`
Agrega un elemento al final del vector.

```
nums.add(5)
nums.add(10)
// Resultado: [1, 2, 3, 4, 5, 10]
```


### `insert(indice, valor)`
Inserta un elemento en una posición específica.

```
nums.insert(0, 6)   // Inserta 6 al inicio
// Resultado: [6, 1, 2, 3, 4]
```


### `get(indice)`
Obtiene el elemento en una posición específica.

```
int valor = nums.get(2)   // Obtiene el elemento en la posición 2
Console.print(valor)      // Muestra el valor
```


### `assign(indice, valor)`
Modifica el elemento en una posición específica.

```
nums.assign(3, 2)   // Cambia el elemento en la posición 3 por 2
// Resultado: [1, 2, 3, 2, 4]
```


### `remove(indice)`
Elimina el elemento en una posición específica.

```
nums.remove(2)   // Elimina el elemento en la posición 2
// Resultado: [1, 2, 4]
```


### `extract()`
Elimina y devuelve el último elemento del vector.

```
int ultimo = nums.extract()
// ultimo = 4
// Resultado: [1, 2, 3]
```


### `contains(valor)`
Verifica si un elemento existe en el vector.

```
bool existe = nums.contains(3)   // true
bool existe = nums.contains(10)  // false
```


### `sort()`
Ordena los elementos del vector en orden ascendente.

```
nums.sort()
// Resultado: [1, 2, 3, 4]
```


### `invest()`
Invierte el orden de los elementos del vector.

```
nums.invest()
// Resultado: [4, 3, 2, 1]
```


### `length()`
Devuelve el número de elementos del vector.

```
int total = nums.length()
Console.print(total)   // Muestra la cantidad de elementos
```


## 4. Métodos adicionales

### `clear()`
Elimina todos los elementos del vector.

```
nums.clear()
// Resultado: []
```

### `isEmpty()`
Verifica si el vector está vacío.

```
bool vacio = nums.isEmpty()
```

### `first()`
Obtiene el primer elemento del vector.

```
int primero = nums.first()
```

### `last()`
Obtiene el último elemento del vector.

```
int ultimo = nums.last()
```

### `indice_de(valor)`
Obtiene la posición de la primera ocurrencia de un valor.

```
int posicion = nums.indexOf(3)
// Si no existe, devuelve -1
```

### `ultimo_indice_de(valor)`
Obtiene la posición de la última ocurrencia de un valor.

```
int posicion = nums.lastIndexOf(3)
```


## 5. Ejemplos completos

### Ejemplo 1: Operaciones básicas con vectores

```
#inject Vector;

Vector<int> numeros = [10, 20, 30, 40]

Console.print("Longitud: " + numeros.length())   // 4

numeros.add(50)                              // [10, 20, 30, 40, 50]
numeros.insert(2, 25)                          // [10, 20, 25, 30, 40, 50]

int valor = numeros.get(3)                  // 30
Console.print("Valor en posición 3: " + valor)

numeros.assign(1, 15)                           // [10, 15, 25, 30, 40, 50]
numeros.remove(0)                              // [15, 25, 30, 40, 50]

int ultimo = numeros.pop()                   // 50
Console.print("Último: " + ultimo)               // Último: 50
```

### Ejemplo 2: Buscar y ordenar

```
#inject Vector;

Vector<int> edades = [25, 18, 30, 22, 19]

bool contiene = edades.contains(22)              // true
int posicion = edades.indexOf(30)              // 2

edades.sort()                                 // [18, 19, 22, 25, 30]
edades.reverse()                                // [30, 25, 22, 19, 18]

int total = edades.length()                    // 5

foreach (edad in edades) {
    Console.print(edad)
}
```

### Ejemplo 3: Uso con entrada de usuario

```
#inject Vector;

Vector<string> nombres = []

while (true) {
    auto nombre = Console.input(text="Ingrese un nombre (o 'salir' para terminar): ")
    
    if (nombre == "salir"):
        break
    
    nombres.add(nombre)
}

Console.print("Nombres ingresados: " + nombres.length())

foreach (nombre in nombres) {
    Console.print("- " + nombre)
}
```


## 6. Comparación entre métodos

| Método | Descripción | Complejidad |
|--------|-------------|-------------|
| `add(valor)` | Agrega al final | O(1) amortizado |
| `insert(indice, valor)` | Inserta en posición | O(n) |
| `get(indice)` | Obtiene por posición | O(1) |
| `assign(indice, valor)` | Modifica por posición | O(1) |
| `remove(indice)` | Elimina por posición | O(n) |
| `pop()` | Elimina el último | O(1) |
| `contains(valor)` | Verifica existencia | O(n) |
| `sort()` | Ordena los elementos | O(n log n) |
| `reverse()` | Invierte el orden | O(n) |
| `length()` | Obtiene longitud | O(1) |


## 7. Errores comunes

### Error 1: No importar la librería

```
Vector<int> nums = []   // error: falta importar vector
```

**Solución:** Importar la librería antes de usar.

```
#inject Vector;
Vector<int> nums = []
```


### Error 2: Índice fuera de rango

```
Vector<int> nums = [1, 2, 3]
int valor = nums.get(5)   // error: índice fuera de rango
```

**Solución:** Verificar que el índice sea menor que `longitud()`.
```
if (5 < nums.length()):
    int valor = nums.get(5)
else:
    Console.print("Índice inválido")
```


### Error 3: Usar métodos en variable no declarada como vector

```
int nums = [1, 2, 3]
nums.add(4)   // error: agregar no es un método de int
```

**Solución:** Declarar la variable como vector.

```
Vector<int> nums = [1, 2, 3]
nums.add(4)
```
