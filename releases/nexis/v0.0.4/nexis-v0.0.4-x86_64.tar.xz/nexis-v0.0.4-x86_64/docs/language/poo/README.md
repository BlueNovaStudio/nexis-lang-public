# 🏛️ Programación orientada a objetos (POO) en Nexis

La programación orientada a objetos permite agrupar **datos** y **comportamiento**. Nexis soporta `struct` para agrupar campos y `class` para crear objetos con campos y métodos.

## Contenido

- [Structs (agrupación de datos)](structs.md)
- [Clases y objetos](classes.md)

## En esta sección aprenderás

- Definir un `struct` con varios campos.
- Definir una `class` con métodos.
- Crear y usar objetos.
- Crear objetos con `NombreClase()` y llamar métodos con `objeto.metodo(...)`.
- Inicializar el estado con `init(self, ...)` y constructores `NombreClase(...)`.

## Referencia rápida

```nexis
// struct: agrupa datos
struct Contacto {
    string nombre;
    string telefono;
    string categoria;
}

// class: datos + métodos
class Cuenta {
    float saldo = 0

    void depositar(float: monto) {
        saldo = saldo + monto
    }

    func consultar() -> float {
        saldo
    }
}

// Uso
Contacto c = Contacto()
c.nombre = "Ana"
c.telefono = "123456"

Cuenta miCuenta = Cuenta()
miCuenta.depositar(500)
float total = miCuenta.consultar()
```

Las clases admiten campos, valores iniciales por tipo, `init(self, ...)`, métodos `void` y `func` con retorno. Herencia y modificadores de acceso aún no están implementados.
