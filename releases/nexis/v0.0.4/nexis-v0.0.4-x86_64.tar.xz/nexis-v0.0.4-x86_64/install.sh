#!/usr/bin/env bash
# =============================================================================
# install.sh — Instalador Linux genérico de Nexis (demo vv0.0.4)
# =============================================================================
# Copia los binarios `nexisc`/`nexisi` y la documentación a un directorio de
# instalación, y añade ese directorio al PATH si está en un shell Bash.
#
# Uso:
#   ./install.sh                    # instala en ~/.local (recomendado)
#   sudo ./install.sh /usr/local    # instalación global (todos los usuarios)
#   INSTALL_DIR=/opt/nexis ./install.sh
# =============================================================================

set -euo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"

# 1. Directorio de instalación (por defecto ~/.local, o /usr/local si es root)
if [ -n "${INSTALL_DIR:-}" ]; then
    PREFIX="$INSTALL_DIR"
elif [ -n "${1:-}" ]; then
    PREFIX="$1"
elif [ "$(id -u)" = "0" ]; then
    PREFIX="/usr/local"
else
    PREFIX="$HOME/.local"
fi

BIN_DIR="$PREFIX/bin"
DOC_DIR="$PREFIX/share/doc/nexis"

COMPONENTS="${NEXIS_COMPONENTS:-all}"
if [ -z "${NEXIS_COMPONENTS:-}" ] && [ -t 0 ]; then
    printf 'Componentes [a]mbos, [c]ompilador o [i]nterprete (a): '
    read -r choice
    case "${choice:-a}" in
        c|C) COMPONENTS="compiler" ;;
        i|I) COMPONENTS="interpreter" ;;
        a|A) COMPONENTS="all" ;;
        *) echo "Opción no válida"; exit 1 ;;
    esac
fi

echo "==> Instalando Nexis demo vv0.0.4 en: $PREFIX"

# 2. Copiar binarios
mkdir -p "$BIN_DIR"
case "$COMPONENTS" in
    all|compiler) install -m 0755 "$SOURCE_DIR/bin/nexisc" "$BIN_DIR/" ;;
esac
case "$COMPONENTS" in
    all|interpreter) install -m 0755 "$SOURCE_DIR/bin/nexisi" "$BIN_DIR/" ;;
esac

# 3. Copiar documentación y compatibilidad
mkdir -p "$DOC_DIR"
cp -r "$SOURCE_DIR/docs/." "$DOC_DIR/" 2>/dev/null || true
cp "$SOURCE_DIR/COMPATIBILIDAD.md" "$DOC_DIR/" 2>/dev/null || true

# 4. Añadir al PATH y registrar exactamente lo que instalamos.
PATH_MARKER="# Nexis vv0.0.4"
touch "${HOME}/.profile"
for SHELL_RC in "${HOME}/.profile" "${HOME}/.bashrc" "${HOME}/.zshrc"; do
    if [ -f "$SHELL_RC" ] && ! grep -Fqs "$PATH_MARKER" "$SHELL_RC"; then
        printf '%s\nexport PATH="%s:$PATH"\n' "$PATH_MARKER" "$BIN_DIR" >> "$SHELL_RC"
    fi
done
printf '%s\n' "$COMPONENTS" > "$PREFIX/.nexis-components"

echo "==> Listo. Prueba con: nexisi --version"
echo "==> Para desinstalar: $SOURCE_DIR/uninstall.sh $PREFIX"
