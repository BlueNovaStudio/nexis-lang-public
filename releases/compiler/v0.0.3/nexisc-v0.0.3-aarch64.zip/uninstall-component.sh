#!/usr/bin/env bash
set -euo pipefail
PREFIX="${INSTALL_DIR:-${1:-$HOME/.local}}"
BIN_DIR="$PREFIX/bin"
rm -f "$BIN_DIR/nexisc" "$PREFIX/.nexis-compiler"
for PROFILE in "$HOME/.profile" "$HOME/.bashrc" "$HOME/.zshrc"; do
    [ -f "$PROFILE" ] && sed -i "/# Nexis compiler v0.0.3/,+1d" "$PROFILE" 2>/dev/null || true
done
echo "Nexis compiler desinstalado de $PREFIX"
