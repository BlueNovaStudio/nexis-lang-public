# Nexis Interpreter (`interpreter/`)

Intérprete de **Nexis V0.0.1**. El binario se llama **`nexisi`** y ofrece dos
modos:

```text
nexisi programa.nxs        # ejecuta un archivo
nexisi --repl              # consola interactiva (REPL)
```

> **Filosofía**: el intérprete no reinventa el lenguaje; **comparte el fronted
> con el compilador**. Reutiliza `nexis_lexer`, `nexis_parser`, `nexis_sema`
> y `nexis_errors` tal cual, y solo aporta un **backend de ejecución**
> (la máquina virtual). El resultado: mismas reglas, mismas fallas, mismas
> salidas que `nexisc` — garantizado por la suite de paridad
> (`scripts/run_interpreter_tests.sh`).

---

## 1. Cómo encaja con el compilador

```text
             ┌────────────────────────── compilador (nexisc) ──────────────────────────┐
 fuente .nxs │ nexis_lexer → nexis_parser → nexis_sema → nexis_codegen (tree-walk)     │
             └────────────────────────────────────────────────────────────────────────┘
                         │                  │                     │
                         ▼                  ▼                     ▼
             ┌────────────────────────── intérprete (nexisi) ─────────────────────────┐
             │ nexis_lexer → nexis_parser → nexis_sema → nexis_vm (backend propio)    │
             └────────────────────────────────────────────────────────────────────────┘
                                   (crates compartidos por path)
```

Los crates del intérprete dependen de los del compilador por **path**:

```toml
# interpreter/crates/nexis_vm/Cargo.toml
nexis_ast   = { path = "../../../compiler/crates/nexis_ast" }
nexis_errors= { path = "../../../compiler/crates/nexis_errors" }
```

Eso significa que cuando el intérprete ejecuta `Program`, está viendo
**el mismo AST** con el que `nexisc` ejecuta y los mismos `Value`.

## 2. Arquitectura del runtime

```text
                 ┌──────────────────────────────────────────────┐
                 │                    Vm (nexis_vm)             │
                 │  ┌───────────── eval (2 backends) ─────────┐ │
                 │  │  Evaluator (tree-walk)   │  dispatch     │ │
                 │  │  → recorre el AST        │  → interpreta  │ │
                 │  │  [BACKEND POR DEFECTO]   │    bytecode    │ │
                 │  └───────────┬────────────────┬────────────┘ │
                 │              ▼                ▼               │
                 │        nexis_runtime::value (SEMÁNTICA)      │
                 │        coerce · format_value · eval_binary   │
                 └──────────────────┬───────────────────────────┘
                                    ▼
                       Runtime { Environment, Gc, errors }
```

Los dos backends "piden prestada" la semántica a
[`nexis_runtime::value`](crates/nexis_runtime/src/value.rs). Como ambos
comparten el mismo código, es imposible que divergan entre sí o con `nexisc`.

### ¿Cuál backend ejecuta?

| Flag | Backend | Cuándo usarlo |
|---|---|---|
| *(ninguna)* | [`TreeWalk`](crates/nexis_vm/src/evaluator.rs) | Por defecto. Paridad 1:1 con `nexisc`. |
| `--bytecode` | [`Bytecode`](crates/nexis_vm/src/vm.rs) | Estudiar cómo se ejecutaría "de verdad" con un dispatch loop. |
| `--debug` | ambos | Traza sentencias, entorno, opcodes y pila. |

## 3. Mapa de crates

```text
interpreter/
├── Cargo.toml              # workspace (5 crates + nexisi)
├── nexisi/                 # el binario
│   └── src/
│       ├── main.rs         # decide modo según args
│       ├── cli.rs          # parsea banderas (--repl, --debug, --bytecode)
│       └── runner.rs       # pipeline lexer→parser→sema→VM
├── crates/
│   ├── nexis_runtime/      # valores, entorno, gc (memoria)
│   ├── nexis_vm/           # la máquina virtual (evaluación)
│   ├── nexis_builtins/     # funciones nativas (Console, I/O, math)
│   └── nexis_repl/         # sesión interactiva persistente
└── scripts/
    ├── run_interpreter_tests.sh   # suite de paridad con nexisc
    └── repl_debug.sh              # REPL con trazas de la VM
```

## 4. El runtime por dentro

### 4.1 `nexis_runtime::value` — las reglas del lenguaje

Es el archivo más importante del intérprete. Aquí no hay "código de VM": es
la **semántica exacta** de Nexis, extraída del compilador y compartida.

```rust
/// Cómo se imprime un valor (idéntico a nexisc).
pub fn format_value(v: &Value) -> String { /* ... */ }

/// Convierte un valor al tipo declarado; Err(mensaje) = error NX60.
pub fn coerce(v: Value, ty: Type) -> Result<Value, String> { /* ... */ }

/// Operadores binarios completos, incluidos los errores NX01.
pub fn eval_binary(op: BinaryOp, l: Value, r: Value, errors: &mut Vec<String>) -> Value
```

Ejemplos de reglas que viven aquí:

- `int a = Console.input(...)` → si la línea no es numérica, `NX60` y `a = 0`.
- `"hola" + 42` → `"hola42"` (concatenación).
- `10 / 0` → `NX01: división entre cero en tiempo de ejecución`.
- `==` entre tipos incompatibles → `false`.

### 4.2 `nexis_runtime::environment` — scopes

Tabla de símbolos (`HashMap<String, Value>`). En V0.0.1 hay **un solo ámbito
global**. Dos reglas heredadas del compilador:

- Una variable **sin inicializador no se registra** en runtime (el sema ya
  emite `NX00` al primer uso).
- Las **constantes** solo existen en el sema (`NX03`); el runtime no las
  distingue.

### 4.3 `nexis_runtime::gc` — memoria

V0.0.1 no necesita recolector (todo son valores primitivos con ownership de
Rust). El `Gc` solo **contabiliza** valores creados y raíces vivas, dejando el
punto de extensión claro para V1.0.0 (funciones/clases = objetos con
referencias).

### 4.4 `nexis_runtime::object`

Estructuras futuras (funciones nativas, funciones Nexis, campos). V0.0.1 no
las expone; es la "caja" que V1.0.0 llenará.

## 5. La VM por dentro (`nexis_vm`)

### 5.1 Evaluador tree-walk (`evaluator.rs`) — el backend por defecto

Traducción directa de `nexis_codegen::Interpreter`:

```rust
pub struct Evaluator<'a> { runtime: &'a mut Runtime, calls: CallStack, debug: bool }

fn eval(&mut self, expr: &Expr) -> Value       // produce el valor de una expresión
fn exec_stmt(&mut self, stmt: &Stmt, _i: usize) // ejecuta una sentencia
fn read_input(&mut self, input: &ConsoleInput) -> String // prompt + lectura
```

Recursión natural sobre el AST: `Binary` evalúa `left`, luego `right`, y
delega la operación en `eval_binary` (mismo orden de evaluación que `nexisc`).

### 5.2 Bytecode (`opcodes.rs` + el dispatch loop)

El ISA de la VM documenta cómo **se compila** cada nodo del AST:

```text
int a = Console.input(text="n: ")   ──►   Push("n: ")
                                              InputExpr{prompt:true}
                                              Store{name:"a", ty:Int}
Console.print(a + 1)                ──►   Load("a")
                                              Push(Int(1))
                                              Op(Add)
                                              Print{count:2, newline:true}
```

El dispatch loop en `vm.rs` (el "bucle principal de ejecución") recorre las
instrucciones, actualiza la `OperandStack` y despacha contra el runtime:

```rust
match ins.op {
    Opcode::Push(v)            => ops.push(v.clone()),
    Opcode::Load(name)         => ops.push(env.get(name)...),
    Opcode::Op(binop)          => {
        let r = ops.pop()...; let l = ops.pop()...;
        ops.push(eval_binary(binop, l, r, &mut self.runtime.errors));
    }
    Opcode::Store {name, ty}   => { /* coerce + env.set */ }
    Opcode::Print {..}         => { /* pop_n + format + stdout */ }
    // ...
}
```

El operando clave es **`Store { name, ty }`**: recuerda el tipo declarado de
una variable para forzar la misma coerción que hace el tree-walk en la
declaración y en la asignación.

### 5.3 Pilas (`stack.rs`)

- `OperandStack`: valores intermedios de las expresiones (backend bytecode).
- `CallStack`: marcos de ejecución (línea/columna) para trazabilidad y, más
  adelante, llamadas a funciones.

## 6. Las builtins (`nexis_builtins`)

| Módulo | Contenido | Estado en V0.0.1 |
|---|---|---|
| `core.rs` | `print`, `println`, `type_of`, `len` | helpers internos de la VM |
| `io.rs` | `prompt`, `read_line`, `write_stdout` | usados por `Console.input/print` |
| `math.rs` | `pow`, `abs`, `floor`, `ceil`, `round`, `sqrt` | semilla de la bib. `math` (V1.0) |

`Console.print`/`println`/`input` son **nodos de AST** en V0.0.1 (no funciones
de primera clase). Las builtins son el *contenido* de esos nodos; por eso la VM
y los futuros `NativeFunction` comparten la misma implementación.

## 7. El REPL (`nexis_repl`)

Una [`Session`](crates/nexis_repl/src/session.rs) guarda una **`Vm`
persistente**: las variables declaradas en una línea siguen vivas en la
siguiente. Cada entrada se compila y ejecuta en esta canalización:

```text
lexer → parser → sema → vm
 (NX91)  (NX90)  (NX00..) (NX01/NX60)
```

Para salir: `exit`, `salir`, `quit` o `Ctrl+D`.

## 8. Uso completo

```bash
cargo build --release --bin nexisi        # en interpreter/

nexisi programa.nxs                       # ejecuta
nexisi --bytecode programa.nxs            # ejecuta con backend bytecode
nexisi --debug programa.nxs               # ejecuta con trazas
nexisi --repl                             # consola interactiva
nexisi --repl --debug --bytecode          # REPL trazando el bytecode
nexisi --help                             # ayuda

./scripts/run_interpreter_tests.sh        # suite de paridad vs nexisc
./scripts/repl_debug.sh                   # REPL con trazas de la VM
```

## 9. Ejemplo real del modo `--debug`

```bash
$ printf 'int a = 5\nint b = a + 3\nConsole.println(a * b)\n' > d.nxs
$ nexisi --bytecode --debug d.nxs | grep -E "Op |Store|println"
[vm] 0004  Op Add                          (línea 2, col 11)
[vm] 0005  Store "b"                       (línea 2, col 1)
[vm] 0008  Op Mul                          (línea 3, col 19)
[vm] 0009  println x1                      (línea 3, col 1)
```

Ves exactamente qué operaciones ejecuta la máquina y en qué posición del
fuente.

## 10. Verificación de paridad

`scripts/run_interpreter_tests.sh` ejecuta cada `.nxs` con **`nexisc`**,
**`nexisi` (tree-walk)** y **`nexisi --bytecode`**, e compara stdout, stderr
y código de salida:

```bash
Resultado: 6 OK, 0 FAIL
```

Si alguna vez un cambio rompe la paridad, el script lo señala con `FAIL` y
muestra la diferencia entre backends.

## 11. Hoja de ruta hacia V1.0.0

- Control de flujo (`if`/`while`/`for`) → nuevos `Stmt`, nuevos opcodes.
- Funciones → `CallStack` real + `Object::NexisFunction` y scopes anidados.
- Errores recuperables (`try`/`catch`) → tipos de error runtime estructurados.
- Clases y colecciones → `Object::Fields` + el GC con barrido de raíces.
- Backend bytecode como **ejecución por defecto** (hoy es opción de estudio).