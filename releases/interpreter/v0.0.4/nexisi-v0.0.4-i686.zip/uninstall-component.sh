#!/usr/bin/env bash
set -euo pipefail
PREFIX="${INSTALL_DIR:-${1:-$HOME/.local}}"
BIN_DIR="$PREFIX/bin"
rm -f "$BIN_DIR/nexisi" "$PREFIX/.nexis-interpreter"
for PROFILE in "$HOME/.profile" "$HOME/.bashrc" "$HOME/.zshrc"; do
    [ -f "$PROFILE" ] && sed -i "/# Nexis interpreter v0.0.4/,+1d" "$PROFILE" 2>/dev/null || true
done
echo "Nexis interpreter desinstalado de $PREFIX"
