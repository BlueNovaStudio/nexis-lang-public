#!/usr/bin/env bash
set -euo pipefail
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
PREFIX="${INSTALL_DIR:-${1:-$HOME/.local}}"
BIN_DIR="$PREFIX/bin"
mkdir -p "$BIN_DIR"
install -m 0755 "$SOURCE_DIR/bin/nexisi" "$BIN_DIR/"
MARKER="# Nexis interpreter v0.0.4"
PROFILE="${HOME}/.profile"
touch "$PROFILE"
if ! grep -Fqs "$MARKER" "$PROFILE"; then
    printf '%s\nexport PATH="%s:$PATH"\n' "$MARKER" "$BIN_DIR" >> "$PROFILE"
fi
printf '%s\n' 'interpreter' > "$PREFIX/.nexis-interpreter"
echo "Nexis interpreter instalado en $PREFIX"
echo "Abre una nueva shell para usar nexisi."
